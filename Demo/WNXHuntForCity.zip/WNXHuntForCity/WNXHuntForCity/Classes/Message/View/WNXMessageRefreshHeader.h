
//
//  WNXMessageHeader.h
//  WNXHuntForCity
//
//  Created by MacBook on 15/7/14.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//  消息页面的下拉动画，设置

#import "MJRefreshGifHeader.h"

@interface WNXMessageRefreshHeader : MJRefreshGifHeader

@end
