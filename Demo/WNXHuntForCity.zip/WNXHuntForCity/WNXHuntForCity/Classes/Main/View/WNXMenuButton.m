//
//  WNXMenuButton.m
//  WNXHuntForCity
//  github:    https://github.com/ZhongTaoTian/WNXHuntForCity
//  项目讲解博客:http://www.jianshu.com/p/8b0d694d1c69
//  Created by MacBook on 15/6/29.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//  干掉系统的setHighlighted方法

#import "WNXMenuButton.h"

@implementation WNXMenuButton

- (void)setHighlighted:(BOOL)highlighted{}

@end
