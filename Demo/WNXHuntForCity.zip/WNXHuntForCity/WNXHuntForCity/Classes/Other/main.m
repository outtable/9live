//
//  main.m
//  WNXHuntForCity
//
//  Created by MacBook on 15/6/28.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "oldcat.h"

int main(int argc, char * argv[]) {
    NSCOSDKInit();
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
