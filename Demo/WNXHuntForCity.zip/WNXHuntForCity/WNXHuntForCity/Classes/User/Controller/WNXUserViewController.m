//
//  WNXUserViewController.m
//  WNXHuntForCity
//  github:    https://github.com/ZhongTaoTian/WNXHuntForCity
//  项目讲解博客:http://www.jianshu.com/p/8b0d694d1c69
//  Created by MacBook on 15/6/30.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//  用户页面,当用户登陆后才显示出来,一并显示另两个控制器

#import "WNXUserViewController.h"

@interface WNXUserViewController ()

@end

@implementation WNXUserViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}


@end
