#!/bin/sh

source ~/.bash_profile

export LANG=en_US.UTF-8

pod env

cd ${WORKSPACE_DIR}

pod update --no-repo-update --verbose