#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
from xml.dom.minidom import parse
import xml.dom.minidom
import random
import re

import confuse_utils

import os
import importlib

importlib.reload(sys)

#sys.setdefaultencoding('utf-8')
 
def write_head(fout):
	fout.write('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n')
	fout.write('<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n')
	pass

def write_tail(fout):
	pass

def write_tab(fout, c):
	for i in range(0, c):
		fout.write('	')
	pass

def write_node(fout, node, tab):
	write_close = False
	if node.nodeType == xml.dom.Node.ELEMENT_NODE:
		write_tab(fout, tab)
		text = '<%s' % node.tagName
		keys = list(node.attributes.keys());
		for i in range(0, len(keys)):
			key = keys[i]
			value = node.getAttribute(key)
			text += ' %s = \"%s\"' % (key, value)

		fout.write(text)
		if len(node.childNodes) == 0:
			fout.write('/>\n')
		else:
			write_close = True
			if node.tagName == 'array' or node.tagName == 'dict' or node.tagName == 'plist':
				fout.write('>\n')
			else:
				fout.write('>')
	elif node.nodeType == xml.dom.Node.CDATA_SECTION_NODE:
		text =  '<![CDATA[%s]]>' % node.data
		fout.write(text)
		pass
	elif node.nodeType == xml.dom.Node.TEXT_NODE:
		text =  node.data
		has_start_tag = text.find('<')
		has_end_tag = text.find('>')
		if has_start_tag != -1 or has_end_tag != -1:
			text =  '<![CDATA[%s]]>' % node.data
			fout.write(text)
		else:
			fout.write(text)
	for child in node.childNodes:
		write_node(fout, child, tab + 1)

	if len(node.childNodes):
		if node.tagName == 'array' or node.tagName == 'dict' or node.tagName == 'plist':
			write_tab(fout, tab)
	if write_close:
		fout.write('</%s>\n' % node.tagName)
	pass

def copy_node(node):
	pairs = []
	key = None
	value = None
	for child in node.childNodes:
		if child.nodeType == xml.dom.Node.ELEMENT_NODE:
			if child.tagName == 'key':
				key = child
			elif key != None:
				pair = [key, copy_node(child)]
				key = None
				pairs.append(pair)
			else:
				pairs.append(copy_node(child))
		else:
			pairs.append(copy_node(child))

	randtemp = []
	if node.tagName != 'array':
		temp = pairs[:]
		while len(temp):
			i = random.randint(0, len(temp) - 1)
			randtemp.append(temp[i])
			del temp[i]
	else:
		randtemp = pairs
		
	childNodes = []

	for pair in randtemp:
		if isinstance(pair, xml.dom.Node):
			childNodes.append(pair)
		else:
			key = pair[0]
			value = pair[1]
			childNodes.append(key)
			childNodes.append(value)

	node.childNodes = childNodes
	return node
	pass

def confuse_plist_file(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('##confuse plist file %s##' % src_file)
	confuse_utils.dbfile_lock()
	src_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	confuse_utils.dbfile_unlock()
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	if not os.path.exists(src_file):
		print('warning:not found %s' % src_file)
		return
	src_file_back = src_file + '.back'
	if os.path.exists(src_file_back):
		os.remove(src_file_back)
	os.link(src_file, src_file_back)
	with open(src_file, 'r') as fin:
		try:
			dom = xml.dom.minidom.parse(fin)
			fin.close()
			os.remove(src_file)
			with open('%s' % src_file, 'w') as fout:
				write_head(fout)
				node = copy_node(dom.documentElement)
				write_node(fout, node, 0)
				fout.close()
		except Exception:
			print('plist file %s format error.' % src_file)
	pass


# cd /Users/crab/Documents/myprojects/clang-confuse/resource/projectmanager/other/script
# python confound_plist_file.py /Users/crab/Documents/swapshell/samplecode/SampleCode/SampleCode/Info.plist /Users/crab/Documents/myprojects/clang-confuse/src/projectmanager/workdir com.my.SampleCode

def main(argv):
	if len(argv) != 13:
		print('python confound_plist_file.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		return
	confuse_plist_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)