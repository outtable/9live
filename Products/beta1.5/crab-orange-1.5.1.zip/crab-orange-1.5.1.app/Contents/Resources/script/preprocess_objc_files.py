#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import json
import confuse_utils

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

def get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	if target_name == None and project_name == None:
		target_dir = '%s/SwiftBridgeHeaders' % (package_dir)
	else:
		target_dir = '%s/SwiftBridgeHeaders/%s/%s' % (package_dir, confuse_utils.md5str(project_name), target_name)
	return target_dir

def preprocess_project_code_file(workspace_dir, work_dir, bundle_id, main_bundle_id, project_file, project_name, task_id, configure, target_name, bardgate_code_rate, is_first_task, is_last_task, depend_user_header_search_paths, depend_project_header_map_files, depend_public_header_map_files, project_header_map_file, public_header_map_file):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)

	if len(main_bundle_id):
		cache_dir = '%s/cache/%s' % (work_dir, main_bundle_id)
	else:
		cache_dir = '%s/cache' % package_dir
	source_cache_dir = '%s/cache' % (package_dir)
	os.system('mkdir -p \"%s\"' % cache_dir)
	
	listen_file = '%s/%s.listenkey' % (package_dir, bundle_id)
	warning_file = '%s/warning.txt' % package_dir
	all_code_file_path = '%s/all-code-files.txt' % package_dir
	code_file_path = '%s/%s.%s.objc.code-files' % (package_dir, project_name, target_name)
	excludes_file_path = '%s/exclude_object_configs.txt' % package_dir
	idmap_path = '%s/idmap.txt' % package_dir
	back_file_dir = '%s/back' % package_dir
	const_string_match_config_file = '%s/const_string_match_configs.txt' % package_dir
	exclude_config_file = '%s/exclude_object_configs.txt' % package_dir
	exclude_all_member_config_file = '%s/exclude_object_configs.txt.ext' % package_dir
	exclude_inflate_config_file = '%s/exclude_inflate_file_configs.txt' % package_dir

	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name, True)
	prefixHeaderPath = confuse_utils.get_build_settings_value(build_settings, 'GCC_PREFIX_HEADER', '')
	framework_search_paths = confuse_utils.get_framework_search_paths_settings_value(build_settings)
	system_framework_search_paths = confuse_utils.get_system_framework_search_paths_settings_value(build_settings)
	
	head_search_paths = confuse_utils.get_header_search_paths_settings_value(build_settings)
	alwaysSearchUserPaths = confuse_utils.get_build_settings_value(build_settings, 'ALWAYS_SEARCH_USER_PATHS', 'YES')
	#user_head_search_paths = []
	#if alwaysSearchUserPaths == 'YES':
	user_head_search_paths = confuse_utils.get_user_header_search_paths_settings_value(build_settings)

	macros = confuse_utils.get_preprocess_settings_value(build_settings, ['OTHER_CFLAGS'])

	source_root = confuse_utils.get_build_settings_value(build_settings, 'SOURCE_ROOT', '')
	head_search_paths.append('%s' % package_dir)
	
	sdk_path = confuse_utils.get_build_settings_value(build_settings, 'SDKROOT', '')
	toolchain_dir = confuse_utils.get_build_settings_value(build_settings, 'TOOLCHAIN_DIR', '')
	clang_dir = confuse_utils.get_clang_dir(build_settings)
	lib_clang_include = confuse_utils.get_clang_resource_dir()

	#platform_arch = confuse_utils.get_build_settings_value(build_settings, 'PLATFORM_PREFERRED_ARCH', 'arm64')
	platform_arch = 'arm64'
	triple_os_version = confuse_utils.get_build_settings_value(build_settings, 'LLVM_TARGET_TRIPLE_OS_VERSION', '')
	if len(triple_os_version) == 0:
		values = confuse_utils.get_build_settings_value(build_settings, 'DEPLOYMENT_TARGET_SUGGESTED_VALUES', [])
		if len(values):
			triple_os_version = 'ios' + values[0]
		else:
			triple_os_version = 'ios6.0'

	enable_arc = confuse_utils.get_build_settings_value(build_settings, 'CLANG_ENABLE_OBJC_ARC', 'NO')
	enable_weak = confuse_utils.get_build_settings_value(build_settings, 'CLANG_ENABLE_OBJC_WEAK', 'NO')
	enable_exception = confuse_utils.get_build_settings_value(build_settings, 'GCC_ENABLE_OBJC_EXCEPTIONS', 'YES')

	allow_non_modular_includes_in_framework_modules = confuse_utils.get_build_settings_value(build_settings, 'CLANG_ALLOW_NON_MODULAR_INCLUDES_IN_FRAMEWORK_MODULES', 'NO')

	cstring_encode = 'false'
	cfstring_encode = 'false'

	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cstring-encode', True):
		cstring_encode = 'true'
		
	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cfstring-encode', True):
		cfstring_encode = 'true'
	
	args = "-bundle-id=%s" % (bundle_id)
	args = "%s\n-listen-file=%s" % (args, listen_file)
	args = "%s\n-target-name=%s" % (args, target_name)
	args = "%s\n-task-id=%s" % (args, task_id)
	args = "%s\n-warning-file=%s" % (args, warning_file)
	args = "%s\n-source-file=%s" % (args, code_file_path)
	args = "%s\n-cache-dir=%s" % (args, cache_dir)
	args = "%s\n-source-cache-dir=%s" % (args, source_cache_dir)
	args = "%s\n-const-string-match-config-file=%s" % (args, const_string_match_config_file)
	args = "%s\n-exclude-config-file=%s" % (args, exclude_config_file)
	args = "%s\n-exclude-all-member-config-file=%s" % (args, exclude_all_member_config_file)
	args = "%s\n-exclude-inflate-config-file=%s" % (args, exclude_inflate_config_file)
	args = "%s\n-configure=%s" % (args, configure)
	if configure == 'Release':
		args = "%s\n-bardgate-code-rate=%s" % (args, bardgate_code_rate)
	args = "%s\n-encode-cstring=%s" % (args, cstring_encode)
	args = "%s\n-encode-cfstring=%s" % (args, cfstring_encode)
	if is_last_task == 'true':
		args = "%s\n-clear-unhit=%s" % (args, 'target')
	args = "%s\n-worker-count=%d" % (args, confuse_utils.get_worker_count(work_dir, bundle_id))
	need_check_error = False
	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-code-error', True):
		args = "%s\n-check-error=%s" % (args, 'true')
		need_check_error = True

	cosdk_name = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cosdk-name', 'COSDK')
	args = "%s\n-cosdk-name=%s" % (args, cosdk_name)
	#args = "%s\n-force=true" % (args)
	#args = "%s\n-cxx-include=%s/usr/include/c++/v1" % (args, toolchain_dir)
	args = "%s\n%s" % (args, project_file)
	args = "%s\n--" % args
	args = "%s\n-Wno-error" % (args)
	args = "%s\n-Wno-int-conversion" % (args)
	args = "%s\n-fmodules" % (args)
	#xcode 12.5
	#args = "%s\n-fcompatibility-qualified-id-block-type-checking" % (args)

	if len(prefixHeaderPath):
		if prefixHeaderPath.startswith('/'):
			args = "%s\n-include%s" % (args, prefixHeaderPath)
		else:
			args = "%s\n-include%s/%s" % (args, source_root, prefixHeaderPath)
			
	args = "%s\n-include%s/default.h" % (args, exe_dir)
	
	if enable_arc == 'YES':
		args = "%s\n-fobjc-arc" % (args)

	if enable_weak == 'YES':
		args = "%s\n-fobjc-weak" % (args)

	if enable_exception == 'NO':
		args = "%s\n-fno-objc-exceptions" % (args)

	if allow_non_modular_includes_in_framework_modules == 'YES':
		args = "%s\n-Werror=non-modular-include-in-framework-module" % (args)

	args = "%s\n-mios-version-min=6.0" % args
	args = "%s\n-isysroot%s" % (args, sdk_path)
	args = "%s\n-resource-dir=%s" % (args, lib_clang_include)
	oldcat_sdk_path = confuse_utils.get_oldcat_sdk_path(work_dir, bundle_id)
	if oldcat_sdk_path != None:
		args = "%s\n-iquote%s/%s" % (args, workspace_dir, oldcat_sdk_path)
	args = "%s\n-F%s/System/Library/Frameworks" % (args, sdk_path)
	#args = "%s\n-ferror-limit=9999999" % args

	args = "%s\n-idirafter%s" % (args, project_header_map_file)
	args = "%s\n-iquote%s" % (args, project_header_map_file)
	args = "%s\n-I%s" % (args, public_header_map_file)

	embed_swift = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'embed-swift', False)
	if embed_swift:
		args = "%s\n-F%s" % (args, get_swift_bridge_headers_dir(work_dir, bundle_id, None, None))
		args = "%s\n-iquote%s" % (args, get_swift_bridge_headers_dir(work_dir, bundle_id, project_file, target_name))

	for framework_search_path in system_framework_search_paths:
		if len(framework_search_path):
			args = "%s\n-iframework%s" % (args, framework_search_path)

	for framework_search_path in framework_search_paths:
		if len(framework_search_path) > 0:
			args = "%s\n-F%s" % (args, framework_search_path)

	for head_search_path in head_search_paths:
		if len(head_search_path) > 0:
			args = "%s\n-I%s" % (args, head_search_path)

	for user_head_search_path in user_head_search_paths:
		if len(user_head_search_path) > 0:
			if alwaysSearchUserPaths == 'YES':
				args = "%s\n-I%s" % (args, user_head_search_path)
			else:
				args = "%s\n-iquote%s" % (args, user_head_search_path)
	
	for user_head_search_path in depend_user_header_search_paths:
		if len(user_head_search_path) > 0:
			args = "%s\n-I%s" % (args, user_head_search_path)

	for project_header_map_file in depend_project_header_map_files:
		if len(project_header_map_file) > 0:
			args = "%s\n-iquote%s" % (args, project_header_map_file)

	for project_header_map_file in depend_public_header_map_files:
		if len(project_header_map_file) > 0:
			args = "%s\n-I%s" % (args, project_header_map_file)

	for macro in macros:
		if len(macro) > 0:
			args = "%s\n-D%s" % (args, macro)

	cmdfile = '%s/%s-%s.objc.cmd.txt' % (package_dir, project_name, target_name)
	with open(cmdfile, 'w') as f:
		f.write(args)
		f.close()

	derived_data_dir = confuse_utils.get_xcode_derived_data_dir()
	cmd = '%s/%s/clang-tools "code-preprocess" "%s" "%s" "%s" "%s" "%s" "objc"' % (exe_dir, clang_dir, work_dir, cmdfile, derived_data_dir, platform_arch, triple_os_version)
	ret = confuse_utils.exec_cmd(cmd)
	#sys.exit(1)
	if ret != 0 and need_check_error:
		sys.exit(1)
	pass

def find_target(projects, dependencie):
	target_name = dependencie['target']
	project_name = dependencie['project']
	for project in projects:
		if project['name'] != project_name:
			continue
		for target in project['targets']:
			if target['name'] == target_name:
				return target, project
	return None, None

def get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, project, target, history):
	project_file = project['path']
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target['name'], True)
	alwaysSearchUserPaths = confuse_utils.get_build_settings_value(build_settings, 'ALWAYS_SEARCH_USER_PATHS', 'YES')
	ret = []
	if alwaysSearchUserPaths == 'YES':
		ret = confuse_utils.get_user_header_search_paths_settings_value(build_settings)
	dependencies = target['dependencies']
	for dependencie in dependencies:
		findtarget,findproject = find_target(projects, dependencie)
		if findtarget == None or findtarget['name'] in history:
			continue
		paths = get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, findproject, findtarget, history)
		for path in paths:
			if path not in ret:
				ret.append(path)
		history.append(findtarget['name'])
	return ret

def get_project_dependenceies(projects, project_file):
	ret = []
	for project in projects:
		path = project['path']
		if path == project_file:
			targets = project['targets']
			for target in targets:
				dependencies =  target['dependencies']
				for dependencie in dependencies:
					ret.append(dependencie)
	return ret
	
def get_project_info_by_name(projects, name):
	for project in projects:
		if project['name'].endswith(name):
			return project
	return None

def get_depend_project_header_files(projects, project_file, project_header_map_files, public_header_map_files):
	dependencies = get_project_dependenceies(projects, project_file)
	for dependenc in dependencies:
		project_name = dependenc['project']
		target_name = dependenc['target']
		project_info = get_project_info_by_name(projects, project_name)
		project_header_map_files.append(project_info['project-header-map-file'])
		public_header_map_files.append(project_info['public-header-map-file'])

def preprocess_objc_files(work_dir, bundle_id, main_bundle_id, workspace_info_file, project_name, task_id, configure, bardgate_code_rate, is_first_task, is_last_task):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	print('preprocess workspace %s objc files' % workspace_info_file)
	found_project = False
	with open(workspace_info_file, 'r') as load_f:
		js = json.load(load_f)
		workspace_dir = confuse_utils.get_file_dir(js['workspace-file'])
		projects = js['projects']
		for project in projects:
			project_file = project['path']
			name = project['name']

			if name != project_name:
				continue

			found_project = True
			targets = project['targets']
			if len(targets) == 0:
				confuse_utils.trace_error('not found targets in project \"%s\"' % name)
			project_header_map_file = project['project-header-map-file']
			public_header_map_file = project['public-header-map-file']
			for target in targets:
				target_name = target['name']
				print('target:%s' % target_name)
				depend_user_header_search_paths = get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, project, target, [])
				depend_project_header_map_files = []
				depend_public_header_map_files = []
				get_depend_project_header_files(projects, project_file, depend_project_header_map_files, depend_public_header_map_files)
				preprocess_project_code_file(workspace_dir, work_dir, bundle_id, main_bundle_id, project_file, confuse_utils.get_file_name(project_name), task_id, configure, target_name, bardgate_code_rate, is_first_task, is_last_task, depend_user_header_search_paths, depend_project_header_map_files, depend_public_header_map_files, project_header_map_file, public_header_map_file)

	if found_project == False:
		confuse_utils.trace_error('not found project \"%s\" in %s' % (project_name, workspace_info_file))
	print('preprocess workspace %s finish' % workspace_info_file)
	pass

# cd /Users/crab/Documents/myprojects/clang-confuse/resource/projectmanager/other/script
# python preprocess_objc_files.py ~/Library/projectmanager com.my.SampleCode ~/Library/projectmanager/packages/com.my.SampleCode/workspace_info.json SampleCode.xcodeproj temp32

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 11:
		print('python preprocess_objc_files.py [work dir] [bundle id] [main bundle id] [workspace info file] [project name] [task id] [Debug/Release] [bardgate code rate] [is first task] [is last task]')
		sys.exit(1)
	preprocess_objc_files(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10])
	
main(sys.argv)