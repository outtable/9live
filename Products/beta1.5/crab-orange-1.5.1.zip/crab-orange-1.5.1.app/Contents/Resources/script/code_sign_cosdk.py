#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def code_sign_cosdk(work_dir, bundle_id, project_file, target_name, configure):
	print('##code sign COSDK.framework')
	cosdk_name = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cosdk-name', 'COSDK')
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	mp,has_config,identify = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, bundle_id, target_name)
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	mobile_provision = mp['FILE_NAME']
	sign_key = mp['CODE_SIGN_IDENTITY']
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	cmds = []
	dst_file = '%s/Products/Applications/%s/Frameworks/%s.framework' % (archive_path, app_product_file, cosdk_name)
	if not os.path.exists(dst_file):
		print('warning:not found %s' % dst_file)
		return
	cmd = 'rm -rf %s/Products/Applications/%s/Frameworks/COSDK.framework/_CodeSignature' % (archive_path, app_product_file)
	cmd = '/usr/bin/codesign -f -s \"%s\" --preserve-metadata=identifier,entitlements,flags \"%s\"' % (sign_key, dst_file)
	cmds.append(cmd)

	for cmd in cmds:
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 6:
		print('python code_sign_cosdk.py [work dir] [bundle id] [project file] [target name] [configure]')
		sys.exit(1)
	code_sign_cosdk(argv[1], argv[2], argv[3], argv[4], argv[5])

main(sys.argv)