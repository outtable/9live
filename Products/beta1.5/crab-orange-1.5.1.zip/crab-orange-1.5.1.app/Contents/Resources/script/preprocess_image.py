#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def preprocess_image(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('preprocess image %s' % (src_file))
	#name = confuse_utils.get_file_name(src_file)
	#file_extension = confuse_utils.get_file_extension(src_file)
	#confuse_utils.add_constant(work_dir, bundle_id, name, file_extension)
	#confuse_utils.add_constant(work_dir, bundle_id, name, '<image>')
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python preprocess_image.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	preprocess_image(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)