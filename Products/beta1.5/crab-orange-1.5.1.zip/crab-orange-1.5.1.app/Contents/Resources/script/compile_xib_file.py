#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

#CompileXIB src/modules/actparty/controller/dancepk/view/DHDancePKNavBar.xib
#    cd /Users/crab/Desktop/dahan/yueyue
#    export PATH="/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin:/Applications/Xcode.app/Contents/Developer/usr/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
#    export XCODE_DEVELOPER_USR_PATH=/Applications/Xcode.app/Contents/Developer/usr/bin/..
#    /Applications/Xcode.app/Contents/Developer/usr/bin/ibtool --errors --warnings --notices --module yueyue 
#--output-partial-info-plist /Users/crab/Desktop/dahan/yueyue/Build/Intermediates.noindex/yueyue.build/Debug-iphoneos/yueyue.build/DHDancePKNavBar-PartialInfo.plist
#--auto-activate-custom-fonts 
#--target-device iphone 
#--minimum-deployment-target 9.0 --output-format human-readable-text 
#--compile /Users/crab/Desktop/dahan/yueyue/Products/Debug-iphoneos/yueyue.app/DHDancePKNavBar.nib /Users/crab/Desktop/dahan/yueyue/src/modules/actparty/controller/dancepk/view/DHDancePKNavBar.xib
def compile_xib_file(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('##compile xib file %s##' % (src_file))
	cmds = []
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, use_cache_file=True)
	module_name = confuse_utils.get_build_settings_value(app_build_settings, 'PRODUCT_MODULE_NAME', '')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	confuse_utils.dbfile_lock()
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	confuse_utils.dbfile_unlock()
	file_name = '%s/%s_environment_variables.txt' % (package_dir, target_name)
	envs = confuse_utils.read_properties_file(file_name)

	supported_device_families = envs['SUPPORTED_DEVICE_FAMILIES']
	items = supported_device_families.split(',')
	target_devices = []

	for item in items:
		if item == '1':
			target_devices.append('iphone')
		elif item == '2':
			target_devices.append('ipad')

	file_name = confuse_utils.get_file_name(src_file)
	confuse_utils.dbfile_lock()
	dst_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	confuse_utils.dbfile_unlock()
	new_file_name = confuse_utils.get_file_name(dst_file)
	if not os.path.exists(dst_file):
		print('warning:not found %s' % dst_file)
		return
       
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)

	path = '%s.nib' % (file_name)
	new_path = '%s.nib' % (new_file_name)

	if len(ref_folder):
		path = '%s/%s' % (ref_folder, path)
		new_path = '%s/%s' % (ref_folder, new_path)

	if product_type == '.framework':
		workspace_profile = confuse_utils.load_workspace_profile(work_dir, bundle_id)
		if confuse_utils.get_target_macho_type(workspace_profile, product_target_name) != 'staticlib':
			path = 'Frameworks/%s/%s' % (product_file, path)
			new_path = 'Frameworks/%s/%s' % (product_file, new_path)
	elif product_type == '.bundle':
		path = '%s/%s' % (product_file, path)
		new_path = '%s/%s' % (product_file, new_path)

	confuse_utils.dbfile_lock()
	confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, path, new_path)
	confuse_utils.dbfile_unlock()
	#remove file
	if product_type == '.appext':
		outfile = '%s/Products/Applications/%s/PlugIns/%s.appext/%s.nib' % (archive_path, app_product_file, new_product_target_name, new_file_name)	
	elif product_type == '.bundle':
		outfile = '%s/Products/Applications/%s/%s/%s.nib' % (archive_path, app_product_file, product_file, new_file_name)
	elif product_type == '.framework':
		outfile = '%s/Products/Applications/%s/Frameworks/%s/%s.nib' % (archive_path, app_product_file, product_file, new_file_name)
	else:
		outfile = '%s/Products/Applications/%s/%s.nib' % (archive_path, app_product_file, new_file_name)
	cmds.append('rm -rf \"%s\"' % outfile)


	cmd = '${SYSTEM_DEVELOPER_BIN_DIR}/ibtool --errors --warnings --notices --auto-activate-custom-fonts --output-format human-readable-text'
	cmd = '%s --module \"%s\"' % (cmd, module_name)
	cmd = '%s --output-partial-info-plist \"${TEMP_DIR}/%s-PartialInfo.plist\"' % (cmd, new_file_name)
	for target_device in target_devices:
		cmd = '%s --target-device %s' % (cmd, target_device)
	cmd = '%s --minimum-deployment-target ${IPHONEOS_DEPLOYMENT_TARGET}' % (cmd)
	cmd = '%s --compile \"%s\" \"%s\"' % (cmd, outfile, dst_file)
	cmds.append(cmd)

	for cmd in cmds:
		ret = confuse_utils.exec_cmd(confuse_utils.replace_text_vars(envs, cmd))
		if ret != 0:
			sys.exit(ret)

	#print 'product-type:%s' % product_type
	#print 'product-file:%s' % product_file
	#print 'product-target-name:%s' % (product_target_name)
	#print 'output-file:%s' % outfile
	#print 'dst-file:%s' % dst_file
	#sys.exit(1)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python compile_xib_file.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	compile_xib_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)