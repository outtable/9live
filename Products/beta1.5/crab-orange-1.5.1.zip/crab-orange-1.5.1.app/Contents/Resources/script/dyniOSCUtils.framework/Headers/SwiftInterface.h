//
//  SwiftInterface.cpp
//  libiOSCUtils
//
//  Created by yang wei on 2024/5/30.
//

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif
    typedef void* listen_file_t;
    
    listen_file_t listenFile_create(const char* name);
    
    void listenFile_delete(listen_file_t pthis);
    
    int listenFile_loadAll(listen_file_t pthis);
    
    void bardageCodeGenerator_load(listen_file_t listenFile);
    
    char* bardageCodeGenerator_getCode();

    int excludeConfigFile_load(const char* name);
    
    int excludeConfigFile_match(const char* fileName);

    int linkFile_create(const char* filename, const char* linkFileName);

    void dataManager_open(const char* filename);

    void dataManager_setBundleAndTarget(const char* bundleId, const char* targetName);

    void dataManager_insertTempFile(const char* fileName);

#ifdef __cplusplus
}
#endif
