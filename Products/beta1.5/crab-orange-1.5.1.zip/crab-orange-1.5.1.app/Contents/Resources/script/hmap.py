#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import struct
import math
import importlib

importlib.reload(sys)
#sys.setdefaultencoding('utf-8')

class HMapString : 
	offset = -1
	value = None

	def __init__(self, value):
		self.offset = -1
		self.value = value.encode('utf-8')
		pass

	def getValue(self):
		if self.value != None:
			return self.value.decode('utf-8')
		return '<invalid>'

	def setValue(self, new_value):
		self.value = new_value.encode('utf-8')
		pass

	def getOffset(self):
		return self.offset

	def setOffset(self, offset):
		self.offset = offset
		pass
		
class HMapStringTable :
	string_byte_array = None
	entity_map = {}
	entity_list = []
	def __init__(self):
		pass

	def load(self, file_data, file_data_size, strings_offset):
		self.string_byte_array = bytearray(file_data[strings_offset:])
		pass

	def save(self, stream):
		stream.write(b'\x00')
		for i in range(0, len(self.entity_list)):
			entity = self.entity_list[i]
			byte_data = bytearray(entity.getValue(), 'utf-8')
			stream.write(byte_data)
			stream.write(b'\x00')

	def readCString(self, byte_array, byte_array_size, offset):
		len = 0
		for i in range(offset, byte_array_size):
			if byte_array[i] == 0:
				break
			len = len + 1
		return str(byte_array[offset:offset + len], 'utf-8')

	def getString(self, offset):
		value = self.readCString(self.string_byte_array, len(self.string_byte_array), offset)
		if value in self.entity_map:
			return self.entity_map[value]
		
		entity = HMapString(value)
		self.entity_map[value] = entity
		self.entity_list.append(entity)
		return entity

	def addString(self, value):
		if value in self.entity_map:
			return self.entity_map[value]
		else:
			entity = HMapString(value)
			self.entity_map[value] = entity
			self.entity_list.append(entity)
			return entity

	def alignOffset(self):
		offset = 1
		for i in range(0, len(self.entity_list)):
			entity = self.entity_list[i]
			entity.setOffset(offset)
			offset = offset + len(entity.getValue()) + 1

class HMapBucket :
	key = None
	prefix = None
	suffix = None

	def __init__(self, key, prefix, suffix):
		self.key = key
		self.prefix = prefix
		self.suffix = suffix
		pass

	def getKeyString(self):
		if self.key == None:
			return '<invalid>'
		return self.key.getValue()

	def getPrefixString(self):
		if self.prefix == None:
			return '<invalid>'
		return self.prefix.getValue()

	def getSuffixString(self):
		if self.suffix == None:
			return '<invalid>'
		return self.suffix.getValue()

	def getKeyOffset(self):
		if self.key == None:
			return 0
		return self.key.getOffset()

	def getPrefixOffset(self):
		if self.prefix == None:
			return 0
		return self.prefix.getOffset()

	def getSuffixOffset(self):
		if self.suffix == None:
			return 0
		return self.suffix.getOffset()

class HMapFile :
	buckets = []
	entitys = []
	string_table = HMapStringTable()
	head_struct = struct.Struct('iHHiiii')
	bucket_struct = struct.Struct('iii')
	
	magic = 0x686d6170
	version = 1
	reserved = 0
	strings_offset = 0
	num_entries = 0
	num_buckets = 0
	max_value_length = 0
	start_bucket_size = 0

	def __init__(self):
		self.buckets = []
		self.entitys = []
		self.string_table = HMapStringTable()
		self.version = 1
		self.reserved = 0
		self.strings_offset = 0
		self.num_entries = 0
		self.num_buckets = 0
		self.max_value_length = 0
		self.start_bucket_size = 0
		pass

	def resizeBuckets(self):
		while True:
			if self.start_bucket_size == 0:
				self.start_bucket_size = 1
			maxBucketSize = self.start_bucket_size * 2
			self.start_bucket_size *= 2
			
			if maxBucketSize < len(self.buckets):
				maxBucketSize = math.pow(2, math.log(len(self.buckets), 2) + 1)

			newBuckets = []
			for i in range(0, maxBucketSize):
				newBuckets.append(None)
			self.buckets = newBuckets
			complete = True
			for entity in self.entitys:
				index = self.getBucketIndex(entity.suffix.getValue())
				found = False
				while index < maxBucketSize - 1:
					if newBuckets[index] == None:
						newBuckets[index] = entity
						found = True
						break
					index = index + 1
				if not found:
					complete = False
					continue

			if complete:
				break
		#self.test()
		pass

	def test(self):
		for entity in self.entitys:
			if self.lookup(entity.getSuffixString()) == None:
				print('error.')
				sys.exit(1)

	def getBucketIndex(self, key):
		lowerKey = key.lower()
		maxBucket = len(self.buckets) - 1
		return self.getKeyHash(lowerKey) & maxBucket
	
	def add(self, prefix, suffix):
		bucket_index = self.lookup(suffix)
		if bucket_index != None:
			#self.buckets[bucket_index].prefix = self.string_table.addString(prefix)
			return
		newBucket = HMapBucket(self.string_table.addString(suffix), self.string_table.addString(prefix), self.string_table.addString(suffix))
		self.entitys.append(newBucket)

		while True:
			index = self.getBucketIndex(suffix)
			found = False
			maxBucketSize = len(self.buckets)
			complete = True
			while index < maxBucketSize - 1:
				if self.buckets[index] == None:
					self.buckets[index] = newBucket
					found = True
					break
				index = index + 1
			if not found:
				self.resizeBuckets()
				complete = False
				
			if complete:
				break
		pass

	def readHead(self, file_data):
		self.magic, self.version, self.reserved, self.strings_offset, self.num_entries, self.num_buckets, self.max_value_length = self.head_struct.unpack_from(file_data)
		pass

	def writeHead(self, stream):
		num_entries = len(self.entitys)
		num_buckets = len(self.buckets)
		max_value_length = 0
		strings_offset = self.head_struct.size + self.bucket_struct.size * num_buckets
		head_pack_data = self.head_struct.pack(self.magic, self.version, self.reserved, strings_offset, num_entries, num_buckets, max_value_length)
		stream.write(head_pack_data)

	def writeBucket(self, stream, i):
		bucket = self.buckets[i]
		if bucket != None:
			#print '%d. write-key-offset:%d key-name:%s' % (i, bucket.getKeyOffset(), bucket.getKeyString())
			bucket_pack_data = self.bucket_struct.pack(bucket.getKeyOffset(), bucket.getPrefixOffset(), bucket.getSuffixOffset())
		else:
			bucket_pack_data = self.bucket_struct.pack(0, 0, 0)
		stream.write(bucket_pack_data)

	def readStringTable(self, file_data):
		self.string_table.load(file_data, len(file_data), self.strings_offset)
		pass

	def writeStringTable(self, stream):
		self.string_table.save(stream)

	def getKeyHash(self, key):
		if isinstance(key, bytes):
			byte_data = key
		else:
			byte_data = bytearray(key, 'utf-8')
		result = 0
		for i in range(0, len(byte_data)):
			bv = byte_data[i]
			tmp = bv
			if bv >= 65 and bv <= 91:
				bv = bv + 97 - 65
			result = (result + bv * 13) & 0xffffffff
		return result

	def readBucket(self, file_data, file_data_offset, i):
		key, prefix, suffix = self.bucket_struct.unpack_from(file_data, file_data_offset)
		if key != 0:
			bucket = HMapBucket(self.string_table.getString(key), self.string_table.getString(prefix), self.string_table.getString(suffix))
			#print('%d. read-key-offset:%d key-name:%s' % (i, key, bucket.getKeyString()))
			self.entitys.append(bucket)
		else:
			bucket = None
		self.buckets.append(bucket)
		pass

	def load(self, file_name):
		self.buckets = []
		self.entitys = []
		string_table = HMapStringTable()
		stream = open(file_name, 'rb')
		file_data = stream.read()
		self.readHead(file_data)
		self.readStringTable(file_data)
		file_data_offset = self.head_struct.size
		for i in range(0, self.num_buckets):
			self.readBucket(file_data, file_data_offset, i)
			file_data_offset += self.bucket_struct.size
		pass

	def save(self, file_name):
		stream = open(file_name, 'wb')
		self.writeHead(stream)
		self.string_table.alignOffset()
		for i in range(0, len(self.buckets)):
			self.writeBucket(stream, i)
		self.writeStringTable(stream)
		pass

	def lookup(self, key):
		lowerKey = key.lower()
		index = self.getBucketIndex(key)
		for i in range(index, len(self.buckets)):
			bucket = self.buckets[i]
			if bucket != None:
				if bucket.key.getValue().lower() == lowerKey:
					return i
		return None

	def dumpBucket(self, stream, i, bucket):
		stream.write('%d] %s%s \n' % (i, bucket.getPrefixString(), bucket.getSuffixString()))
		stream.write('\tprefix = %s\n' % (bucket.getPrefixString()))
		stream.write('\tsuffix = %s\n' % (bucket.getSuffixString()))
		pass

	def map(self):
		ret = {}
		for i in range(0, len(self.entitys)):
			entity = self.entitys[i]
			key = entity.getPrefixString()
			value = entity.getSuffixString()
			ret[key + value] = value
		return ret

	def dump(self, stream):
		stream.write('====== header struct ======')
		stream.write('magic:%d\n' % self.magic)
		stream.write('version:%d\n' % self.version)
		stream.write('reserved:%d\n' % self.reserved)
		stream.write('strings-offset:%d\n' % self.strings_offset)
		stream.write('num-entries:%d\n' % len(self.entitys))
		stream.write('num-buckets:%d\n' % len(self.buckets))
		stream.write('max-value-length:%d\n' % self.max_value_length)
		for i in range(0, len(self.entitys)):
			self.dumpBucket(stream, i, self.entitys[i])
		pass