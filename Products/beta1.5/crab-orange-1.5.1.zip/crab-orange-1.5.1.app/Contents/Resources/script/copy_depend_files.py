#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os

import confuse_utils

def copy_file(work_dir, bundle_id, src_file, dst_file):
	print('##copy depend file %s to %s##' % (src_file, dst_file))
	confuse_utils.fast_copy_file(src_file, dst_file)
	confuse_utils.add_backup_file(work_dir, bundle_id, src_file, dst_file)
	pass

def copy_depend_files(workspace_file, work_dir, bundle_id):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	depends_dir = '%s/depends' % package_dir
	depend_filename = '%s/depend_files.txt' % package_dir
	settings = confuse_utils.read_settings_file(depend_filename)
	#print '加载成功!'
	source_root = workspace_file[:workspace_file.rfind('/')]

	items = []
	if 'info.plist' in settings:
		infoplist = settings['info.plist']
		for item in infoplist:
			items.append(item)

	if '*.xcasset' in settings:
		xcasset = settings['*.xcasset']
		for item in xcasset:
			items.append(item)

	if '*.*' in settings:
		other = settings['*.*']
		for item in other:
			items.append(item)

	for f in items:
		src_file = '%s/%s' % (depends_dir, f.replace('../', '{..}/'))
		dst_file = '%s/%s' % (source_root, f)
		copy_file(work_dir, bundle_id, src_file, dst_file)

	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 4:
		print('python copy_depend_files.py [*.xcworkspace] [work dir] [bundle id]')
		sys.exit(1)
	copy_depend_files(argv[1], argv[2], argv[3])

main(sys.argv)