#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

#CompileStoryboard /Users/crab/Desktop/DebugModel/DebugModel/Base.lproj/Main.storyboard (in target: DebugModel)
#   cd /Users/crab/Desktop/DebugModel
#    export XCODE_DEVELOPER_USR_PATH=/Applications/Xcode.app/Contents/Developer/usr/bin/..
#    /Applications/Xcode.app/Contents/Developer/usr/bin/ibtool --errors --warnings --notices 
#--module DebugModel 
#--output-partial-info-plist /Users/crab/Desktop/DebugModel/Build/Intermediates.noindex/DebugModel.build/Debug-iphoneos/DebugModel.build/Base.lproj/Main-SBPartialInfo.plist 
#--auto-activate-custom-fonts --target-device iphone --minimum-deployment-target 9.0 --output-format human-readable-text 
#--compilation-directory /Users/crab/Desktop/DebugModel/Build/Intermediates.noindex/DebugModel.build/Debug-iphoneos/DebugModel.build/Base.lproj /Users/crab/Desktop/DebugModel/DebugModel/Base.lproj/Main.storyboard
def compile_storyboard_file(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('##compile storyboard file %s##' % (src_file))
	cmds = []
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, use_cache_file=True)
	module_name = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_MODULE_NAME', '')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	confuse_utils.dbfile_lock()
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	confuse_utils.dbfile_unlock()
	env_file_name = '%s/%s_environment_variables.txt' % (package_dir, target_name)
	envs = confuse_utils.read_properties_file(env_file_name)

	supported_device_families = envs['SUPPORTED_DEVICE_FAMILIES']
	items = supported_device_families.split(',')
	target_devices = []

	for item in items:
		if item == '1':
			target_devices.append('iphone')
		elif item == '2':
			target_devices.append('ipad')
	dst_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	if not os.path.exists(dst_file):
		print('warning:not found %s' % dst_file)
		return

	file_name = confuse_utils.get_file_name(src_file)
	new_file_name = confuse_utils.get_file_name(dst_file)
	path = '%s.storyboardc' % (file_name)
	new_path = '%s.storyboardc' % (new_file_name)

	if len(ref_folder):
		path = '%s/%s' % (ref_folder, path)
		new_path = '%s/%s' % (ref_folder, new_path)

	if product_type == '.framework':
		workspace_profile = confuse_utils.load_workspace_profile(work_dir, bundle_id)
		if confuse_utils.get_target_macho_type(workspace_profile, product_target_name) != 'staticlib':
			path = 'Frameworks/%s.framework/%s' % (product_target_name, path)
			new_path = 'Frameworks/%s.framework/%s' % (product_target_name, new_path)

	src_dir = 'Base.lproj'
	confuse_utils.dbfile_lock()
	confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, '%s/%s' % (src_dir, path), '%s/%s' % (src_dir, new_path))
	confuse_utils.dbfile_unlock()

	cmd = '${SYSTEM_DEVELOPER_BIN_DIR}/ibtool --errors --warnings --notices --auto-activate-custom-fonts --output-format human-readable-text'
	cmd = '%s --module \"%s\"' % (cmd, module_name)
	cmd = '%s --output-partial-info-plist \"${TEMP_DIR}/%s/%s-PartialInfo.plist\"' % (cmd, src_dir, file_name)
	for target_device in target_devices:
		cmd = '%s --target-device %s' % (cmd, target_device)
	cmd = '%s --minimum-deployment-target ${IPHONEOS_DEPLOYMENT_TARGET}' % (cmd)
	compdir = '${TARGET_TEMP_DIR}/%s' % (confuse_utils.pstr(src_dir))
	cmd = '%s --compilation-directory \"%s\" \"%s\"' % (cmd, compdir, confuse_utils.pstr(dst_file))
	cmds.append('mkdir -p \"%s\"' % compdir)
	cmds.append('rm -rf \"${TARGET_TEMP_DIR}/%s/%s.storyboardc\"' % (src_dir, file_name))
	cmds.append(cmd)

	for cmd in cmds:
		ret = confuse_utils.exec_cmd(confuse_utils.replace_text_vars(envs, cmd))
		if ret != 0:
			sys.exit(ret)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python compile_storyboard_file.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	compile_storyboard_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)