from pbxproj.pbxsections.PBXGroup import PBXGroup

class PBXVariantGroup(PBXGroup):
    pass
