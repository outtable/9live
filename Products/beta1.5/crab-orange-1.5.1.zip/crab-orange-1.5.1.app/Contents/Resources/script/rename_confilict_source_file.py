#!/usr/bin/python
# -*- coding: UTF-8 -*-

def check_confilict_source_files(work_dir, bundle_id):
	rename_confilict_source_file = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'rename-confilict-source-file', False)
	if not rename_confilict_source_file:
		return
	project_info = confuse_utils.load_workspace_profile(work_dir, bundle_id)
	projects = project_info['projects']
	for project in projects:
        targets = project['targets']
        object_names = {}
        source_files = targets['source-files']
        for source_file in source_files:
            for file_type in source_file.keys():
                files = source_file[file_type]
                for file in files:
                    file_path = file['path']
                    name = confuse_utils.get_file_name(file_path).lower()
                    if name not in object_names:
                        object_names[name] = 0
                    else:
                        ext = confuse_utils.get_file_extension(file_path)
                        count = object_names[name] + 1
                        object_names[name] = count
                        new_path = confuse_utils.get_file_dir(file_path) + '/' + name + "_" + count + "." + ext
                        confuse_utils.add_file_rename(work_dir, bundle_id, path, new_path, false)
        break
	pass

def main(argv):
	print(' '.join(argv))
	if len(argv) != 3:
		print('python rename_confilict_source_files.py [work dir] [bundle id]')
		sys.exit(1)
	check_confilict_source_files(argv[1], argv[2])
main(sys.argv)
