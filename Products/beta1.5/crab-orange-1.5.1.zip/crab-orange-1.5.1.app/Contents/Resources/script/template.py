#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
import os
import subprocess
import hashlib
import shutil

_create_time='####CREATE_TIME####'

def md5str(val):
	m1 = hashlib.md5()
	m1.update(bytearray(val, 'utf-8'))	
	return m1.hexdigest()

def restore(linkfilelist):
	back_file = '%s.%s.back' % (linkfilelist, _create_time)
	if os.path.exists(back_file) and not os.path.exists(linkfilelist):
		os.rename(back_file, linkfilelist)
pass

def renamefile(filename):
	name = filename[filename.rfind('/') + 1:filename.rfind('.o')]
	return name + '-%s.o' % md5str(filename)

def exchange(linkfilelist):
	exchange_file = '%s.%s.exchange' % (linkfilelist, _create_time)
	if os.path.exists(exchange_file):
		return
	back_file = '%s.%s.back' % (linkfilelist, _create_time)
	shutil.copyfile(linkfilelist, back_file)
	obj_dir = '/var/tmp/%s' % (md5str(linkfilelist))
	os.system('mkdir -p \"%s\"' % obj_dir)
	lines = []
	new_lines = []
	with open(linkfilelist) as f:
		lines = f.readlines()
		for line in lines:
			file1 = line.strip() + '.tmp'
			file2 = '%s/%s' % (obj_dir, renamefile(file1))
			os.rename(file1, file2)
			os.link(file2, file1)
			new_lines.append(file2)
		f.close()
	with open(linkfilelist, 'w') as f:
		for line in new_lines:
			f.write('%s\n' % line)
		f.close()
	with open(exchange_file, 'w') as f:
		f.write('1')
		f.close()
pass

def load_exec_pos():
	pos = 0
	try:
		f = open('/var/tmp/exec_pos_%s' % _create_time, mode='r')
		pos = int(f.read())
	except:
		pass
	return pos

def save_exec_pos(pos):
	f = open('/var/tmp/exec_pos_%s' % _create_time, mode='w')
	f.write(str(pos))
	f.close()
pass

def exec_cmd(cmd):
	print('🦶 %s' % cmd)
	process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	stdout, stderr = process.communicate()
	text = stdout.decode()
	if len(text):
		print(text)
	ret = process.poll()
	if ret != 0:
		if len(text):
			print(('~>❌ 🦶 %s(ExitCode:%d)' % (cmd, ret)))
		else:
			print(('~>❌ (ExitCode:%d)' % (ret)))
		print(stderr.decode())
	return ret

def exec_cmd_list(cmdlist, save_pos = True, start = 0):
	i = start
	j = len(cmdlist)
	while i < j:
		cmd = cmdlist[i]
		if type(cmd) == str:
			ret = exec_cmd(cmd)
			if ret != 0:
				sys.exit(1)
		else:
			cmd()
		i = i + 1
		if save_pos:
			save_exec_pos(i)