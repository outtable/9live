#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def copy_file(work_dir, bundle_id, src_file, dst_file):
	print('back depend file %s to %s' % (src_file, dst_file))
	confuse_utils.fast_copy_file(src_file, dst_file)
	confuse_utils.add_backup_file(work_dir, bundle_id, src_file, dst_file)
	pass

def back_depend_files(workspace_file, work_dir, bundle_id):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	back_dir = '%s/back' % package_dir
	depend_filename = '%s/depend_files.txt' % package_dir
	settings = confuse_utils.read_settings_file(depend_filename)
	workspace_dir = workspace_file[:workspace_file.rfind('/')]

	if os.path.exists(back_dir) == False:
		os.system('mkdir -p \"%s\"' % back_dir)
		
	all_items = []
	for key in list(settings.keys()):
		if key == 'cosdk':
			continue
		items = settings[key]
		for item in items:
			all_items.append(item)

	for item in all_items:
		src_file = '%s/%s' % (workspace_dir, item)
		dst_file = '%s/%s' % (back_dir, item.replace('../', '{..}/'))
		#print src_file
		#print dst_file
		copy_file(work_dir, bundle_id, src_file, dst_file)

	pass

def main(argv):
	if len(argv) != 4:
		print('python back_depend_files.py [*.xcworkspace] [work dir] [bundle id]')
		sys.exit(1)
	back_depend_files(argv[1], argv[2], argv[3])

main(sys.argv)