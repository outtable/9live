#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
from xml.dom.minidom import parse
import xml.dom.minidom
import shutil
import subprocess
import importlib
 
abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

importlib.reload(sys)
#sys.setdefaultencoding('utf-8')

def get_rel_file_name(name, app_dir):
	return os.path.relpath(name, app_dir)

def confuse_SymbolMap(work_dir, bundle_id, main_project_file, configure, target_name, product_type, product_file, install_dir, project_file, product_target_name, filename, ref_folder):
	print('##confuse %s SymbolMap##' % (target_name))
	
	if len(ref_folder) == 0:
		ref_folder = 'Data/Managed'
		
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	app_dir = '%s/Products/Applications/%s' % (archive_path, app_product_file)
	name = confuse_utils.get_file_name(filename)
	oldfilename = '%s/%s%s' % (app_dir, '%s/' % ref_folder if len(ref_folder) else '', name)
	newfilename = '%s/%s%s.cp' % (app_dir, '%s/' % ref_folder if len(ref_folder) else '', name)


	workspace_dir = os.environ['WORKSPACE_DIR']
	project_file = '%s/Unity-iPhone.xcodeproj' % (workspace_dir)
	cmd = "%s/MapFileParser.sh" % (workspace_dir)

	if not os.path.exists(cmd):
		return
	if os.path.exists(filename):
		os.remove(filename)

	file_name = '%s/%s_environment_variables.txt' % (package_dir,target_name)
	envs = confuse_utils.read_properties_file(file_name)
	envs['UNITY_SCRIPTING_BACKEND'] = 'il2cpp'
	envs['ARCHS'] = 'armv7'
	envs['TARGET_TEMP_DIR'] = envs['CONFIGURATION_TEMP_DIR'] + '/UnityFramework.build'
	envs['PRODUCT_NAME'] = 'UnityFramework'
	#envs['SYNCHRONOUS_SYMBOL_PROCESSING'] = 'TRUE'
	#os.system(cmd)
	sp = subprocess.Popen(cmd, env = envs, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	out = sp.stdout.read()
	print(out)

	if not os.path.exists(filename):
		print('warning:not found %s.' % (filename))
		return;
		#sys.exit(1)

	shutil.copyfile(filename, oldfilename)

	dbfile = '%s/symbols.db' % work_dir
	input_link_map_file = '%s/%s-LinkMap-%s-armv7.txt' % (envs['TARGET_TEMP_DIR'], envs['PRODUCT_NAME'], envs['CURRENT_VARIANT'])
	back_input_link_map_file = input_link_map_file + '.back'
	output_link_map_file = '%s/%s-LinkMap-%s-armv7.new.txt' % (envs['TARGET_TEMP_DIR'], envs['PRODUCT_NAME'], envs['CURRENT_VARIANT'])
	if os.path.exists(back_input_link_map_file):
		if os.path.exists(input_link_map_file):
			os.remove(input_link_map_file)
		os.rename(back_input_link_map_file, input_link_map_file)
	shutil.copyfile(input_link_map_file, back_input_link_map_file)

	print(input_link_map_file)
	print(output_link_map_file)

	print('%s/linkmap-rewriter \"--listen-file=%s/%s.listenkey\" --bundle-id=\"%s\" --dbfile=\"%s\" --input=\"%s\" --output=\"%s\"' % (exe_dir, package_dir, bundle_id, bundle_id, dbfile, confuse_utils.pstr(input_link_map_file), confuse_utils.pstr(output_link_map_file)))
	
	ret = os.system('%s/linkmap-rewriter \"--listen-file=%s/%s.listenkey\" --bundle-id=\"%s\" --dbfile=\"%s\" --input=\"%s\" --output=\"%s\"' % (exe_dir, package_dir, bundle_id, bundle_id, dbfile, confuse_utils.pstr(input_link_map_file), confuse_utils.pstr(output_link_map_file)))

	if ret != 0:
		print('linkmap-rewriter ErrorCode(%d)' % ret)
		sys.exit(1)
	os.remove(input_link_map_file)
	os.rename(output_link_map_file, input_link_map_file)

	sp = subprocess.Popen(cmd, env = envs, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	out = sp.stdout.read()
	print(out)

	if not os.path.exists(filename):
		print('MapFileParser execute error.')
		sys.exit(1)

	shutil.copyfile(filename, newfilename)

	#confuse_utils.dbfile_lock()
	confuse_utils.add_path_to_map(work_dir, bundle_id, target_name, get_rel_file_name(oldfilename, app_dir), get_rel_file_name(newfilename, app_dir), confuse_utils.PathType_Ruote)
	#confuse_utils.dbfile_unlock()
	#os.exit(1)
	os.remove(back_input_link_map_file)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python confuse_TypesInScenes.py  [work dir] [bundle id] [main project file] [configure] [target name] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	confuse_SymbolMap(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])

main(sys.argv)
