#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
import os

from pbxproj import XcodeProject
from pbxproj import PBXAggregateTarget
from pbxproj import XCConfigurationList
from pbxproj import XCBuildConfiguration
from pbxproj import PBXTargetDependency
from pbxproj import PBXContainerItemProxy


import datetime
import confuse_utils
import random;
import json
from xml.dom.minidom import parse
import xml.dom.minidom

import importlib

importlib.reload(sys)

PRODUCT_TYPE_STATIC = 'com.apple.product-type.library.static'

PRODUCT_TYPE_DYNAMIC = 'com.apple.product-type.library.dynamic'

PRODUCT_TYPE_APPLICATION = 'com.apple.product-type.application'

PRODUCT_TYPE_APPEXTENSION = 'com.apple.product-type.app-extension'

PRODUCT_TYPE_FRAMEWORK = 'com.apple.product-type.framework'

MACH_O_TYPE_DYNAMIC = 'mh_dylib'

MACH_O_TYPE_EXECUTE = 'mh_execute'

ccache_enable = False
check_symbol_convert = False
check_link_file = False
check_link_symbol = False
check_target_file = False
check_code_file = False
dump_target_file_log = False
require_ui_kit = False
embed_swift = False
use_dyn_cosdk = False
replace_main = False
link_type = 'main-target'
cosdk_framework_dir = ''
cosdk_name = 'COSDK'
exchange_object_file = True
workspace_file = ''
rename_confilict_source_file = False
require_swift_libraries = False

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

old_cat_a_path = ''

clang_version = 14

def array_copy(items):
	ret = []
	for item in items:
		ret.append(item)
	return ret

def get_target_by_name(project, project_name, target_name):
	#obj =  project.get_target_by_name(target_name)
	#return obj
	rootObject = project.get_object(project.rootObject)
	if rootObject == None:
		print('❌ 工程 %s 格式不支持. %s' % (project_name,project.rootObject))
		sys.exit(1)
		return None
	for targetId in rootObject.targets:
		targetObject = project.get_object(targetId)
		targetName = targetObject['name']
		if targetName == target_name:
			return targetObject
	return None

def get_abs_path(relpath, source_root, file_info):
	path = file_info['path']
	name = file_info['name']

	if path == None:
		return os.path.abspath(relpath)

	if file_info.sourceTree == 'SOURCE_ROOT':
		abspath = source_root + '/' + path
	elif file_info.sourceTree == 'BUILT_PRODUCTS_DIR' or file_info.sourceTree == 'SDKROOT':
		abspath = '${%s}/%s' % (file_info.sourceTree, path)
		return abspath
	else:
		abspath = relpath + '/' + path
	return os.path.abspath(abspath)
	
def get_frameworks_build_phase(project, target_object, ret):
	buildPhases = target_object['buildPhases']
	for phraseId in buildPhases:
		project.get_object
		phraseObject = project.get_object(phraseId)
		if isinstance(phraseObject, project._get_class_reference('PBXFrameworksBuildPhase')):
			files = phraseObject['files']
			for fileId in files:
				file = project.get_object(fileId)
				fileRefId = file['fileRef']
				ret.append(fileRefId)

	dependencies = target_object['dependencies']
	for dependencieId in dependencies:
		dependencieObject = project.get_object(dependencieId)
		targetId = dependencieObject['target']
		targetObject = project.get_object(targetId)
		if targetObject == None:
			continue
		if targetObject['productType'] == 'com.apple.product-type.library.static':
			get_frameworks_build_phase(project, targetObject, ret)
			productReference = project.get_object(targetObject.productReference)
			if productReference.sourceTree == 'BUILT_PRODUCTS_DIR':
				ret.append(targetObject.productReference)

def get_embed_frameworks_build_phase(project, target_object, ret):
	buildPhases = target_object['buildPhases']
	for phraseId in buildPhases:
		phraseObject = project.get_object(phraseId)
		if isinstance(phraseObject, project._get_class_reference('PBXCopyFilesBuildPhase')):
			files = phraseObject['files']
			for fileId in files:
				file = project.get_object(fileId)
				fileRefId = file['fileRef']
				ret.append(fileRefId)

def get_exclude_source_file_names(envs):
	items1 =  confuse_utils.get_build_settings_value(envs, 'EXCLUDED_SOURCE_FILE_NAMES[sdk=iphoneos*][arch=*]', [], 'YES')
	items2 = confuse_utils.get_build_settings_value(envs, 'EXCLUDED_SOURCE_FILE_NAMES', [], 'YES')
	for item in items2:
		if item not in items1:
			items1.append(item)
	return items1

def filter_frameworks_and_libraries_and_search_paths(othre_flags, frameworks, libraries, framework_search_paths, library_search_paths):
	state = 0
	result = []
	for i in range(0, len(othre_flags)):
		item = othre_flags[i]
		if state == 0:
			#print('😄%s' % item)
			if item == '-framework' or item == '-weak_framework':
				state = 1
			elif item == '-iframework':
				state = 2
			elif item.startswith('-ld'):
				result.append(item)
			elif item.startswith('-l'):
				name = item[2:]
				if name.startswith('\"') and name.endswith('\"'):
					name = name[1:-1]
				exists = False
				for v in libraries:
					if v == name:
						exists = True
				if exists == False:
					libraries.append(name)
			elif item.startswith('-L'):
				library_search_paths.append(item[2:])
			elif item.startswith('-F'):
				framework_search_paths.append(item[2:])
			else:
				result.append(item)
		elif state == 1:
			name = item
			if name == '-framework' or item == '-weak_framework':
				continue
			elif name.startswith('-l'):
				state = 0
				i = i - 1
				continue
			elif name.startswith('-L'):
				state = 0
				continue
			exists = False
			for v in libraries:
				if v == name:
					exists = True
			if exists == False:
				frameworks.append(name)
			state = 0
		elif state == 2:
			name = item
			#print('😊-iframework:%s' % name)
			state = 0

	return result

workspace_profile = None

def load_workspace_profile(package_dir):
	global workspace_profile
	if workspace_profile == None:
		file = '%s/workspace.profile' % (package_dir)
		workspace_profile = json.load(open(file, 'r'))
	return workspace_profile

def get_project_dependenceies(profile, project_file, target_name):
	ret = []
	for project in profile['projects']:
		path = project['path']
		if path == project_file:
			targets =  project['targets']
			for target in targets:
				cur_target_name = target['name']
				if cur_target_name == target_name:
					ret = target['dependencies']
					break
			break
	return ret

def get_project_info_by_name(profile, name):
	for project in profile['projects']:
		if project['name'].endswith(name):
			return project
	return None

def get_target_info_by_name(project_info, name):
	targets = project_info['targets']
	for target in targets:
		if target['name'] == name:
			return target
	return None

def get_all_link_targets(project_info, target_name):
	ret = [target_name]
	history = [target_name]
	pos = 0
	while pos < len(history):
		length = len(history)
		target_info = get_target_info_by_name(project_info, history[pos])
		if target_info != None:
			dependencies = target_info['dependencies']
			for dependenc in dependencies:
				exists = False
				for item in ret:
					if item == dependenc:
						exists = True
						break
				if exists == False:
					dependenc_target_info = get_target_info_by_name(project_info, dependenc['target'])
					if dependenc_target_info != None:
						if len(dependenc_target_info['dependencies']):
							found = False
							for item in history:
								if item == dependenc:
									found = True
							if found == False:
								history.append(dependenc['target'])
					ret.insert(0, dependenc['target'])
		pos = pos + 1
	return ret

def get_depend_projects(ret, package_dir, project_file, target_name):
	profile = load_workspace_profile(package_dir)
	#found project
	#print('😄 targetName:%s' % target_name)
	dependencies = get_project_dependenceies(profile, project_file, target_name)
	project_depend_map = {}
	for dependenc in dependencies:
		project_name = dependenc['project']
		cur_target_name = dependenc['target']
		project_info = get_project_info_by_name(profile, project_name)
		if project_name in project_depend_map:
			all_targets = project_depend_map[project_name]
			append_once(all_targets, cur_target_name)
		else:
			all_targets = [cur_target_name]
			project_depend_map[project_name] = all_targets
		dep_targets = []
		get_depend_targets(dep_targets, project_info, cur_target_name)
		for dep_target in dep_targets:
			append_once(all_targets, dep_target['target'])

	for project_name in project_depend_map.keys():
		all_targets = project_depend_map[project_name]
		project_info = get_project_info_by_name(profile, project_name)
		project_file_path = project_info['path']
		#found all link targets
		#print('😊 dependencies: %s project:%s' % (all_targets, project_file_path))
		get_depend_projects(ret, package_dir, project_file_path, cur_target_name)
		ret.append({'project_file' : project_file_path, 'targets' : all_targets, 'project_info' : project_info})

def get_depend_targets(ret, project_info, target_name):
	targets = project_info['targets']
	project_name = project_info['name']
	for target in targets:
		if target['name'] == target_name:
			#print '####get_depend_targets####\n'
			#print '%s\n' % target
			if 'dependencies' in target:
				for item in target['dependencies']:
					if item['project'] != project_name:
						continue
					append_once(ret, item)
			break

def create_confuse_archives_script_text(configure, arch, work_dir, bundle_id, phase, confuse_archive_file, workspace_dir, cache_dir, package_dir, script_dir):
	global dump_target_file_log
	cmd = '%s/archive-rewriter ' % (script_dir)
	cmd = '%s --phase=%s' % (cmd, phase)
	cmd = '%s \"--arch=%s\"' % (cmd, arch)
	cmd = '%s \"--configure=%s\"' % (cmd, configure)
	cmd = '%s \"--cache-dir=%s\"' % (cmd, cache_dir)
	cmd = '%s \"--work-dir=%s\"' % (cmd, work_dir)
	cmd = '%s \"--script-dir=%s\"' % (cmd, script_dir)
	cmd = '%s \"--package-dir=%s\"' % (cmd, package_dir)
	cmd = '%s \"--dbfile=%s/symbols.db\"' % (cmd, work_dir)
	cmd = '%s \"--bundle-id=%s\" \"--sysroot=${SDKROOT}\" ' % (cmd, bundle_id)
	cmd = '%s --worker-count=%d' % (cmd,confuse_utils.get_worker_count(work_dir, bundle_id))
	cmd = '%s \"--listen-file=%s/%s.listenkey\"' % (cmd, package_dir, bundle_id)
	cmd = '%s \"--work-space-dir=%s\"' % (cmd, workspace_dir)
	cmd = '%s \"--confuse-archives-file=%s\"' % (cmd, confuse_archive_file)
	if dump_target_file_log:
		cmd = '%s \"--dump-target-file-log\"' % cmd
	return cmd

def list2Dict(items):
	ret = {}
	for item in items:
		pairs = item.split('=')
		if len(pairs) == 2:
			name = pairs[0].strip()
			value = pairs[1].strip()
			ret[name] = value
	return ret

def create_preprocess_archives_cmds(cmds, configure, archs, work_dir, bundle_id, cache_dir, package_dir, workspace_dir, confuse_archive_file, script_dir):
	if not os.path.exists(confuse_archive_file):
		return
	for arch in archs:
		cmds.append(create_confuse_archives_script_text(configure, arch, work_dir, bundle_id, 'preprocess-archives', confuse_archive_file, workspace_dir, cache_dir, package_dir, script_dir))
	pass

def create_confuse_archives_cmds(cmds, configure, archs, work_dir, bundle_id, cache_dir, package_dir, workspace_dir, confuse_archive_file, script_dir):
	if not os.path.exists(confuse_archive_file):
		return
	for arch in archs:
		cmds.append(create_confuse_archives_script_text(configure, arch, work_dir, bundle_id, 'confuse-archives', confuse_archive_file, workspace_dir, cache_dir, package_dir, script_dir))
	pass

def create_link_archives_cmds(cmds, configure, archs, work_dir, bundle_id, package_dir, workspace_dir, confuse_archive_file):
	if not os.path.exists(confuse_archive_file):
		return
	archive_settings = confuse_utils.read_settings_file(package_dir + '/all_confuse_archive_configs.txt')
	if 'archives' not in archive_settings:
		return
	archives = archive_settings['archives']
	for archive in archives:
		archive_setting = archive_settings[archive]
		archive_info = list2Dict(archive_setting)
		file_path = archive_info['file']
		if len(file_path) == 0:
			continue
		if not file_path.startswith('/'):
			file_path = workspace_dir + '/' + file_path
		arch_dirs = []
		arch_bins = []

		if file_path.endswith('.framework'):
			file_path = '%s/%s' % (file_path, confuse_utils.get_file_name(file_path))

		for arch in archs:
			binary_file_name = confuse_utils.get_full_file_name(file_path)
			arch_dir = '\"%s.unarchive/%s\"' % (file_path, arch)
			arch_bin = '\"%s.unarchive/%s/%s\"' % (file_path, arch, binary_file_name)
			arch_dirs.append(arch_dir)
			arch_bins.append(arch_bin)

		if file_path.endswith('.framework'):
				file_path = '%s/%s' % (file_path, confuse_utils.get_file_name(file_path))
		cmd_group = []
		cmds.append(cmd_group)
		cmd = 'rm \"%s\"' % file_path
		cmd_group.append(cmd)
		cmd = 'lipo -create %s -output \"%s\"' % (' '.join(arch_bins), file_path)
		cmd_group.append(cmd)
		#暂时移除
		#if configure != 'Debug':
		#	for arch_dir in arch_dirs:
		#		cmd = 'rm -rf %s' % arch_dir
		#		cmd_group.append(cmd)
	pass

def create_rewriter_macho_script_text(configure, archive, project, script_dir, work_dir, cache_dir, bundle_id, package_dir, work_space_dir, archive_settings_file, project_name, target_name, new_target_name, arch, framework_search_paths, library_search_paths, frameworks, libraries, embed_frameworks, phase, input_files, exclude_input_files, product_target_name, new_product_target_name, product_name, has_cpp, has_swift):
	cmd = '%s/archive-rewriter ' % (script_dir)
	cmd = '%s --phase=%s' % (cmd, phase)
	cmd = '%s \"--arch=%s\"' % (cmd, arch)
	cmd = '%s \"--configure=%s\"' % (cmd, configure)
	if archive != None:
		cmd = '%s \"--product-file=%s\"' % (cmd, archive)
	cmd = '%s \"--work-dir=%s\"' % (cmd, work_dir)
	cmd = '%s \"--cache-dir=%s\"' % (cmd, cache_dir)
	cmd = '%s \"--script-dir=%s\"' % (cmd, script_dir)
	cmd = '%s \"--package-dir=%s\"' % (cmd, package_dir)
	cmd = '%s \"--input-dir=${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s\"' % (cmd, project_name, product_target_name, arch)
	cmd = '%s \"--input=%s/%s-%s.LinkFileList\"' % (cmd, package_dir, project_name, product_target_name)
	cmd = '%s \"--source-map-file=%s/%s-%s.SourceMap.LinkFileList\"' % (cmd, package_dir, project_name, product_target_name)
	if input_files != None:
		for input_file in input_files:
			cmd = '%s \"--product-input=%s\"' % (cmd, input_file)

	cmd = '%s \"--exclude-input=%s/%s-%s.Exclude.LinkFileList\"' % (cmd, package_dir, project_name, product_target_name)

	cmd = '%s \"-F${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-F${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)

	#if exclude_input_files != None:
	#	for exclude_input_file in exclude_input_files:
	#		cmd = '%s --product-exclude-input=%s' % (cmd, exclude_input_file)
	cmd = '%s -l\"c\"' % cmd
	if has_cpp:
		cmd = '%s -l\"c++\"' % cmd
	for framework_search_path in framework_search_paths:
		cmd = '%s \"-F%s\"' % (cmd, confuse_utils.pstr(framework_search_path))
	for library_search_path in library_search_paths:
		cmd = '%s \"-L%s\"' % (cmd, confuse_utils.pstr(library_search_path))
	for framework in frameworks:
		cmd = '%s \"-f%s\"' % (cmd, framework)
	for embed_framework in embed_frameworks:
		cmd = '%s \"-ef%s\"' % (cmd, embed_framework)

	swift_libraries = []
	if embed_swift:
		import_libs = []
		if require_swift_libraries:
			import_libs.append('swiftObjectiveC')
			import_libs.append('swiftFoundation')
		if require_ui_kit:
			import_libs.append('swiftUIKit')
			import_libs.append('swiftQuartzCore')
			import_libs.append('swiftCoreImage')
		for import_lib in import_libs:
			append_once(swift_libraries, import_lib)

	for library in libraries:
		cmd = '%s -l\"%s\"' % (cmd, confuse_utils.pstr(library))

	for library in swift_libraries:
		cmd = '%s -l\"%s\"' % (cmd, confuse_utils.pstr(library))

	cmd = '%s \"--dbfile=%s/symbols.db\"' % (cmd, work_dir)
	cmd = '%s \"--bundle-id=%s\" \"--sysroot=${SDKROOT}\" ' % (cmd, bundle_id)
	cmd = '%s \"-L${SDKROOT}/usr/lib/swift\"' % (cmd)#swift默认搜索目录
	cmd = '%s \"--target=%s\" ' % (cmd, product_target_name)
	cmd = '%s \"--exclude-config-file=%s/exclude_object_configs.txt\"' % (cmd, package_dir)
	cmd = '%s \"--exclude-config-ext-file=%s/exclude_object_configs.txt.ext\"' % (cmd, package_dir)
	cmd = '%s \"--product-archive-files=%s/product_archive_files.txt\"' % (cmd, package_dir)
	cmd = '%s \"--workspace-link-map=%s/workspace.linkmap\"' % (cmd, package_dir)
	cmd = '%s \"--target-link-map=${LD_MAP_FILE_PATH}\"' % (cmd)
	cmd = '%s \"--link-type=%s\"' % (cmd, link_type)
	cmd = '%s --worker-count=%d' % (cmd,confuse_utils.get_worker_count(work_dir, bundle_id))
	if phase == 'confuse':
		cmd = '%s \"--output=${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList.tmp\"' % (cmd, project_name, product_target_name, arch, product_name)
		if configure != 'Debug':
			cmd = '%s \"--enable-dwarf-confuse\"' % cmd
	if check_symbol_convert == True:
		cmd = '%s \"--check-symbol-convert\"' % cmd
	if check_link_file == True:
		cmd = '%s \"--check-link-file\"' % cmd
	if check_code_file == True:
		cmd = '%s \"--check-code-file\"' % cmd
	if check_target_file == True:
		cmd = '%s \"--check-target-file\"' % cmd
	if check_link_symbol == True:
		cmd = '%s \"--check-link-symbol\"' % cmd
	if phase != 'preprocess':
		cmd = '%s \"--listen-file=%s/%s.listenkey\"' % (cmd, package_dir, bundle_id)

	if ccache_enable:
		cmd = '%s \"--ccache-enable\"' % cmd
	cmd = '%s --keep-format-file=\"%s/keep_format.txt\"' % (cmd, script_dir)

	if dump_target_file_log:
		cmd = '%s \"--dump-target-file-log\"' % cmd

	if phase == 'checkcache':
		cmd = '%s \"--work-space-dir=%s\"' % (cmd, work_space_dir)
		cmd = '%s \"--confuse-archives-file=%s\"' % (cmd, archive_settings_file)
		cmd = '%s \"--block-newname-file=%s/block_newname_configs.txt\"' % (cmd, package_dir)

	if replace_main:
		cmd = '%s \"--replace-main\"' % cmd
	return cmd

#def create_rewriter_archive_script_text(project, script_dir, work_dir, cache_dir, bundle_id, package_dir, project_name, target_name, product_file, framework_search_paths, library_search_paths, frameworks, libraries, phase):
#	ret = ''
#	cmd = '%s/archive-rewriter ' % (script_dir)
#	cmd = '%s --work-dir=%s' % (cmd, script_dir)
#	cmd = '%s --input=${BUILD_DIR}/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s/%s' % (cmd, target_name, product_file)
#	cmd = '%s --exclude-input=%s/%s-%s.Exclude.LinkFileList' % (cmd, package_dir, project_name, target_name)
#	for framework_search_path in framework_search_paths:
#		cmd = '%s -F%s' % (cmd, framework_search_path)
#	for library_search_path in library_search_paths:
#		cmd = '%s -L%s' % (cmd, library_search_path)
#	for framework in frameworks:
#		cmd = '%s -f%s' % (cmd, framework)
#	for library in libraries:
#		cmd = '%s -l%s' % (cmd, library)
#	cmd = '%s --dbfile=%s/symbols.db' % (cmd, work_dir)
#	cmd = '%s --phase=%s --cache-dir=%s' % (cmd, phase, cache_dir)
#	cmd = '%s --bundle-id=%s --sysroot=${SDKROOT} ' % (cmd, bundle_id)
#	cmd = '%s --exclude-file=%s/exclude_object_configs.txt' % (cmd, package_dir)
#	cmd = '%s --worker-count=4' % cmd
#	if phase == 'confuse':
#		file_ext = confuse_utils.get_file_extension(product_file)
#		cmd = '%s --output=${BUILD_DIR}/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s/lib%s.tmp.%s' % (cmd, target_name, product_file[3:-(len(file_ext) + 1)], file_ext)
#	ret = '%s%s' % (ret, cmd)
#	return ret

def create_link_archive_script_text(package_dir, configure, build_settings, product_type, product_file, arch, frameworks, libraries, custom_libraries, framework_search_paths, library_search_paths, other_flags, project_name, target_name, product_target_name, new_product_target_name, mach_o_type, product_name, has_cpp, has_swift):
	cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/libtool'
	if product_type == PRODUCT_TYPE_STATIC:
		cmd = '%s -static' % cmd
	else:
		cmd = '%s -dynamic' % cmd

	cmd = '%s -arch_only %s -D' % (cmd, arch)
	cmd = '%s -syslibroot \"${SDKROOT}\"' % (cmd)

	global cosdk_framework_dir
	global cosdk_name
	cmd = '%s \"-F%s\"' % (cmd, cosdk_framework_dir)

	cmd = '%s \"-F${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-F${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)
	
	for framework_search_path in framework_search_paths:
		cmd = '%s \"-F%s\"' % (cmd, framework_search_path)

	for framework in frameworks:
		cmd = '%s -framework \"%s\"' %(cmd, confuse_utils.pstr(framework))

	cmd = '%s -framework %s' % (cmd, cosdk_name)

	for library_search_path in library_search_paths:
		cmd = '%s \"-L%s\"' % (cmd, library_search_path)

	#print('😄:%s(%s)' % (product_target_name, custom_libraries))
	
	if product_type != PRODUCT_TYPE_STATIC:
		if clang_version == 15:
			cmd = '%s -ld64' % cmd
		
		for library in libraries:
			ln = confuse_utils.pstr(library)
			if library.startswith('/'):
				cmd = '%s \"%s\"' % (cmd, ln)
			else:
				cmd = '%s -l\"%s\"' % (cmd, ln)
		
		for other_flag in other_flags:
			cmd = '%s %s' % (cmd, other_flag)

		if not has_cpp:#只有非cpp的target才加c++，如果是cpp会出链接阶段错误
			cmd = '%s -l\"c++\"' % (cmd)
	else:
		for library in custom_libraries:
			if library.endswith('.tmp'):#不需要把 build phrase 里面生成的加进来
				continue
			cmd = '%s -l\"%s\"' % (cmd, confuse_utils.pstr(library))
		if has_swift:
			temp_archive_dir = '%s/temp-archive-dir' % package_dir
			cmd = '%s \"-L%s\"' % (cmd, temp_archive_dir)
			cmd = '%s -lCOSDK_swift' % (cmd)

	ext = confuse_utils.get_file_extension(product_file)
	full_product_name = product_file[0:-(len(ext) + 1)]
	if configure == 'Release' and exchange_object_file == True:
		linklistfile = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList' % (project_name, product_target_name, arch, product_name)
	else:
		linklistfile = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList.tmp' % (project_name, product_target_name, arch, product_name)		
	cmd = '%s -filelist \"%s\"' % (cmd, linklistfile)
	output = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.tmp.%s' % (project_name, product_target_name, arch, full_product_name, ext)
	cmd = '%s -o \"%s\"' % (cmd, output)
	return cmd, output, linklistfile

def create_link_execute_script_text(package_dir, configure, build_settings, arch, frameworks, libraries, framework_search_paths, library_search_paths, runtime_search_paths, other_flags, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_name, has_cpp, has_swift):
	stdlib = confuse_utils.get_build_settings_value(build_settings, 'CLANG_CXX_LIBRARY', 'libc++')
	enable_arc = confuse_utils.get_build_settings_value(build_settings, 'CLANG_ENABLE_OBJC_ARC', 'NO')
	#enable_bitcode = get_configure_setting_value(envs, build_settings, xcconfig_settings, 'ENABLE_BITCODE', True)
	gen_map_file = confuse_utils.get_build_settings_value(build_settings, 'LD_GENERATE_MAP_FILE', 'YES')
	enable_bitcode = False
	min_target_version = confuse_utils.get_build_settings_value(build_settings, 'IPHONEOS_DEPLOYMENT_TARGET', '6.0')
	#product_name = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_NAME', product_target_name)
	product_file = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')
	clang = 'clang'
	if has_cpp:
		clang = 'clang++'
	cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/%s -arch %s' % (clang, arch)
	cmd = '%s  -isysroot \"${SDKROOT}\"' % (cmd)

	global cosdk_framework_dir
	global cosdk_name
	cmd = '%s \"-F%s\"' % (cmd, cosdk_framework_dir)
	cmd = '%s \"-F${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-F${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)

	for framework_search_path in framework_search_paths:
		cmd = '%s \"-F%s\"' % (cmd, confuse_utils.pstr(framework_search_path))
	for library_search_path in library_search_paths:
		cmd = '%s \"-L%s\"' % (cmd, confuse_utils.pstr(library_search_path))

	if configure == 'Release' and exchange_object_file == True:
		linklistfile = '${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList' % (project_name,product_target_name,arch,product_name)
	else:
		linklistfile = '${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList.tmp' % (project_name,product_target_name,arch,product_name)	
	cmd = '%s -filelist \"%s\"' % (cmd, linklistfile)
	#cmd = '%s -Xlinker -no_adhoc_codesign' % (cmd)
	
	if has_swift:
		cmd = '%s -Xlinker -rpath -Xlinker /usr/lib/swift' % (cmd)
		cmd = '%s -Xlinker -rpath -Xlinker @executable_path/Frameworks' % (cmd)
		if clang_version < 15:#Xcode15上就不需要了
			cmd = '%s -Xlinker -objc_abi_version -Xlinker 2' % (cmd)
		cmd = '%s -L${TOOLCHAIN_DIR}/usr/lib/swift/${PLATFORM_NAME}' % (cmd)
		cmd = '%s -L/usr/lib/swift' % (cmd)
		cmd = '%s -Xlinker -add_ast_path -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.swiftmodule\"' % (cmd, project_name, product_target_name, arch, product_name)
		#cmd = '%s -Xlinker -sectcreate -Xlinker __TEXT ' % (cmd)

	cmd = '%s -miphoneos-version-min=%s' % (cmd, min_target_version)
	cmd = '%s -dead_strip' % (cmd)

	cmd = '%s -Xlinker -object_path_lto -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s_lto.o\"' %(cmd, project_name, product_target_name, arch, product_name)
	
	if gen_map_file == 'YES':
		cmd = '%s -Xlinker -map -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/%s-LinkMap-normal-%s.txt\"' % (cmd, project_name, product_target_name, new_product_target_name, arch)

	if enable_bitcode:
		cmd = '%s -fembed-bitcode  -Xlinker -bitcode_verify -Xlinker -bitcode_hide_symbols -Xlinker -bitcode_symbol_map' % (cmd)
	
	if configure == 'Debug':
		cmd = '%s -Xlinker -export_dynamic -Xlinker -no_deduplicate' % cmd

	cmd = '%s -Xlinker -final_output' % (cmd)
	cmd = '%s -Xlinker \"/Applications/%s/%s\"' % (cmd, product_file,  product_name)
	cmd = '%s -stdlib=%s -fobjc-link-runtime' % (cmd,stdlib)

	if clang_version == 15:
		cmd = '%s -ld64' % cmd
	
	#if use_dyn_cosdk == False:
	#cmd = '%s -force_load \"%s\"' % (cmd, confuse_utils.pstr(old_cat_a_path))

	if enable_arc == 'YES':
		cmd = '%s -fobjc-arc' % cmd

	if len(runtime_search_paths):
		for runtime_search_path in runtime_search_paths:
			cmd = '%s -Xlinker -rpath -Xlinker \"%s\"' % (cmd, confuse_utils.pstr(runtime_search_path))

	links = ''

	for framework_search_path in framework_search_paths:
		links = '%s \"-F%s\"' % (links,  confuse_utils.pstr(framework_search_path))

	for library_search_path in library_search_paths:
		links = '%s \"-L%s\"' % (links,  confuse_utils.pstr(library_search_path))

	temp_archive_dir = '%s/temp-archive-dir' % package_dir
	links = '%s \"-L%s\"' % (links, temp_archive_dir)

	for other_flag in other_flags:
		links = '%s %s' % (links, other_flag)

	for framework in frameworks:
		#if framework == 'COSDK':现在看没啥用，以后不只有没有用，有空再打开
		#	continue
		links = '%s -framework \"%s\"' %(links, confuse_utils.pstr(framework))
	
	links = '%s -framework \"%s\"' %(links, cosdk_name)

	for library in libraries:
		if library.startswith('/'):
			links = '%s \"%s\"' % (links, confuse_utils.pstr(library))
		else:
			links = '%s -l\"%s\"' % (links, confuse_utils.pstr(library))
	
	links = '%s -lCOSDK_swift' % (links)

	cmd = '%s %s' %(cmd, links)
	full_product_name = product_file[0:product_file.rfind('.')]
	cmd = '%s -Xlinker -dependency_info -Xlinker \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s_dependency_info.dat\"' % (cmd, project_name, product_target_name, arch, new_product_target_name)
	output = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s' % (project_name, product_target_name, arch, product_name)
	cmd = '%s -o \"%s\"' % (cmd, output)
	return cmd, output, linklistfile

def create_link_appextension_script_text(project_info, configure, build_settings, arch, frameworks, libraries, framework_search_paths, library_search_paths, runtime_search_paths, other_flags, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_name, has_cpp, has_swift):
	stdlib = confuse_utils.get_build_settings_value(build_settings, 'CLANG_CXX_LIBRARY', 'libc++')
	enable_arc = confuse_utils.get_build_settings_value(build_settings, 'CLANG_ENABLE_OBJC_ARC', 'NO')
	#enable_bitcode = get_configure_setting_value(envs, build_settings, xcconfig_settings, 'ENABLE_BITCODE', True)
	gen_map_file = confuse_utils.get_build_settings_value(build_settings, 'LD_GENERATE_MAP_FILE', 'YES')
	enable_bitcode = False
	min_target_version = confuse_utils.get_build_settings_value(build_settings, 'IPHONEOS_DEPLOYMENT_TARGET', '6.0')
	#product_name = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_NAME', product_target_name)

	clang = 'clang'
	if has_cpp:
		clang = 'clang++'
	cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/%s -arch %s' % (clang, arch)
	cmd = '%s  -isysroot \"${SDKROOT}\"' % (cmd)

	global cosdk_framework_dir
	global cosdk_name
	cmd = '%s \"-F%s\"' % (cmd, cosdk_framework_dir)

	cmd = '%s \"-F${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-F${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)

	for framework_search_path in framework_search_paths:
		cmd = '%s \"-F%s\"' % (cmd, confuse_utils.pstr(framework_search_path))
	for library_search_path in library_search_paths:
		cmd = '%s \"-L%s\"' % (cmd, confuse_utils.pstr(library_search_path))

	if configure == 'Release' and exchange_object_file == True:
		linklistfile = '${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList' % (project_name,product_target_name,arch,product_name)
	else:
		linklistfile = '${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList.tmp' % (project_name,product_target_name,arch,product_name)	
	cmd = '%s -filelist \"%s\"' % (cmd, linklistfile)
	#cmd = '%s -Xlinker -rpath -Xlinker @executable_path/Frameworks -Xlinker -rpath -Xlinker @executable_path/../../Frameworks' % cmd
	cmd = '%s -miphoneos-version-min=%s' % (cmd, min_target_version)
	cmd = '%s -dead_strip' % (cmd)

	cmd = '%s -Xlinker -object_path_lto -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s_lto.o\"' %(cmd, project_name, product_target_name, arch, new_product_target_name)
	
	if gen_map_file == 'YES':
		cmd = '%s -Xlinker -map -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/%s-LinkMap-normal-%s.txt\"' % (cmd, project_name, product_target_name, new_product_target_name, arch)

	if enable_bitcode:
		cmd = '%s -fembed-bitcode  -Xlinker -bitcode_verify -Xlinker -bitcode_hide_symbols -Xlinker -bitcode_symbol_map' % (cmd)
	
	if configure == 'Debug':
		cmd = '%s -Xlinker -export_dynamic -Xlinker -no_deduplicate' % cmd
	
	cmd = '%s -Xlinker -final_output' % (cmd)
	cmd = '%s -Xlinker \"/Applications/%s/PlugIns/%s/%s\"' % (cmd, app_product_file, product_file, product_name)
	cmd = '%s -stdlib=%s -fobjc-link-runtime' % (cmd,stdlib)
	if enable_arc == 'YES':
		cmd = '%s -fobjc-arc' % cmd
	cmd = '%s -fapplication-extension -e _NSExtensionMain' % cmd
	if len(runtime_search_paths):
		for runtime_search_path in runtime_search_paths:
			cmd = '%s -Xlinker -rpath -Xlinker \"%s\"' % (cmd, confuse_utils.pstr(runtime_search_path))

	links = ''

	for framework_search_path in framework_search_paths:
		links = '%s \"-F%s\"' % (links, confuse_utils.pstr(framework_search_path))

	for library_search_path in library_search_paths:
		links = '%s \"-L%s\"' % (links, confuse_utils.pstr(library_search_path))

	for other_flag in other_flags:
		links = '%s %s' % (links, other_flag)

	for framework in frameworks:
		links = '%s -framework \"%s\"' %(links, confuse_utils.pstr(framework))

	if has_swift:
		temp_archive_dir = '%s/temp-archive-dir' % package_dir
		links = '%s \"-L%s\"' % (links, temp_archive_dir)
		links = '%s -lCOSDK_swift' % (links)

	links = '%s -framework %s' %(links, cosdk_name)
	if clang_version == 15:
		links = '%s -ld64' % links
	
	for library in libraries:
		if library.startswith('/'):
			links = '%s \"%s\"' % (links, confuse_utils.pstr(library))
		else:
			links = '%s -l\"%s\"' % (links, confuse_utils.pstr(library))

	cmd = '%s %s' %(cmd, links)
	cmd = '%s -Xlinker -dependency_info -Xlinker \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s_dependency_info.dat\"' % (cmd, project_name, product_target_name, arch, new_product_target_name)
	output = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s' % (project_name, product_target_name, arch, product_target_name)
	cmd = '%s -o \"%s\"' % (cmd, output)
	return cmd, output, linklistfile

def create_link_framework_script_text(package_dir, configure, build_settings, arch, frameworks, libraries, custom_libraries, framework_search_paths, library_search_paths, runtime_search_paths, other_flags, project_name, target_name, new_target_name, product_target_name, new_product_target_name, mach_o_type, product_name, has_cpp, has_swift):
	stdlib = confuse_utils.get_build_settings_value(build_settings, 'CLANG_CXX_LIBRARY', 'libc++')
	enable_arc = confuse_utils.get_build_settings_value(build_settings, 'CLANG_ENABLE_OBJC_ARC', 'NO')
	compatibility_version = confuse_utils.get_build_settings_value(build_settings, 'DYLIB_COMPATIBILITY_VERSION', '')
	current_version = confuse_utils.get_build_settings_value(build_settings, 'DYLIB_CURRENT_VERSION', '')
	gen_map_file = confuse_utils.get_build_settings_value(build_settings, 'LD_GENERATE_MAP_FILE', 'YES')
	product_file = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')
	#enable_bitcode = get_configure_setting_value(envs, build_settings, xcconfig_settings, 'ENABLE_BITCODE', True)
	enable_bitcode = False
	min_target_version = confuse_utils.get_build_settings_value(build_settings, 'IPHONEOS_DEPLOYMENT_TARGET', '6.0')

	if mach_o_type != MACH_O_TYPE_DYNAMIC:
		cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/libtool -static'
		cmd = '%s -arch_only %s -D' % (cmd, arch)
		cmd = '%s -syslibroot \"${SDKROOT}\"' % (cmd)
	else:
		clang = 'clang'
		if has_cpp:
			clang = 'clang++'

		cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/%s -arch %s' % (clang, arch)
		cmd = '%s -dynamiclib -isysroot \"${SDKROOT}\"' % (cmd)
		if len(compatibility_version):
			cmd = '%s -compatibility_version %s' % (cmd, compatibility_version)
		if len(current_version):
			cmd = '%s -current_version %s' % (cmd, current_version)

	global cosdk_framework_dir
	global cosdk_name
	cmd = '%s \"-F%s\"' % (cmd, cosdk_framework_dir)

	cmd = '%s \"-F${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-F${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${BUILT_PRODUCTS_DIR}\"' % (cmd)
	cmd = '%s \"-L${UNINSTALLED_PRODUCTS_DIR}\"' % (cmd)
	
	for framework_search_path in framework_search_paths:
		cmd = '%s \"-F%s\"' % (cmd, confuse_utils.pstr(framework_search_path))
		
	for framework in frameworks:
		cmd = '%s -framework \"%s\"' %(cmd, confuse_utils.pstr(framework))

	cmd = '%s -framework %s' % (cmd, cosdk_name)

	for library_search_path in library_search_paths:
		cmd = '%s \"-L%s\"' % (cmd, confuse_utils.pstr(library_search_path))
	
	if mach_o_type == MACH_O_TYPE_DYNAMIC:
		if clang_version == 15:
			cmd = '%s -ld64' % cmd

		for library in libraries:
			if library.startswith('/'):
				cmd = '%s \"%s\"' % (cmd, confuse_utils.pstr(library))
			else:
				cmd = '%s -l\"%s\"' %(cmd, confuse_utils.pstr(library))
		
		if has_swift:
			temp_archive_dir = '%s/temp-archive-dir' % package_dir
			cmd = '%s \"-L%s\"' % (cmd, temp_archive_dir)
			cmd = '%s -lCOSDK_swift' % (cmd)
	else:
		for library in custom_libraries:
			if library.endswith('.tmp'):#不需要把build phrase的加进来
				continue
			cmd = '%s -l\"%s\"' %(cmd, confuse_utils.pstr(library))

	if configure == 'Release' and exchange_object_file == True:
		linklistfile = '${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList' % (project_name,product_target_name,arch,product_name)
	else:
		linklistfile = '${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList.tmp' % (project_name,product_target_name,arch,product_name)	
	cmd = '%s -filelist \"%s\"' % (cmd, linklistfile)

	if mach_o_type == MACH_O_TYPE_DYNAMIC:
		cmd = '%s -miphoneos-version-min=%s' % (cmd, min_target_version)
		cmd = '%s -dead_strip' % (cmd)
		if has_swift:
			cmd = '%s -Xlinker -rpath -Xlinker /usr/lib/swift' % (cmd)
			cmd = '%s -Xlinker -rpath -Xlinker @executable_path/Frameworks' % (cmd)
			cmd = '%s -Xlinker -objc_abi_version -Xlinker 2' % (cmd)
			cmd = '%s -L${TOOLCHAIN_DIR}/usr/lib/swift/${PLATFORM_NAME}' % (cmd)
			cmd = '%s -L/usr/lib/swift' % (cmd)
			cmd = '%s -Xlinker -add_ast_path -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.swiftmodule\"' % (cmd, project_name, product_target_name, arch, product_name)

		cmd = '%s -install_name @rpath/%s.framework/%s' % (cmd, product_name, product_name)
		
		if configure == 'Debug':
			cmd = '%s -Xlinker -export_dynamic -Xlinker -no_deduplicate' % cmd
		
		if enable_bitcode:
			cmd = '%s -fembed-bitcode  -Xlinker -bitcode_verify -Xlinker -bitcode_hide_symbols -Xlinker -bitcode_symbol_map' % (cmd)
		
		if gen_map_file == 'YES':
			cmd = '%s -Xlinker -map -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/%s-LinkMap-normal-%s.txt\"' % (cmd, project_name, product_target_name, new_product_target_name, arch)

		cmd = '%s -stdlib=%s -fobjc-link-runtime' % (cmd,stdlib)
		if enable_arc == 'YES':
			cmd = '%s -fobjc-arc' % cmd

		if len(runtime_search_paths):
			for runtime_search_path in runtime_search_paths:
				cmd = '%s -Xlinker -rpath -Xlinker \"%s\"' % (cmd, confuse_utils.pstr(runtime_search_path))

		cmd = '%s -Xlinker -object_path_lto -Xlinker \"${TEMP_ROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s_lto.o\"' %(cmd, project_name, product_target_name, arch, new_product_target_name)
		cmd = '%s -Xlinker -dependency_info -Xlinker \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s_dependency_info.dat\"' % (cmd, project_name, product_target_name, arch, product_target_name)
		#cmd = '%s -Xlinker -no_adhoc_codesign' % (cmd) Xcode11.7 上不支持

		links = ''

		for other_flag in other_flags:
			links = '%s %s' % (links, other_flag)

		if not has_cpp:#只有非cpp的target才加c++，如果是cpp会出链接阶段错误
			links = '%s -l\"c++\"' % (links)

		cmd = '%s %s' %(cmd, links)

	output = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s' % (project_name, product_target_name, arch, product_name)
	
	cmd = '%s -o \"%s\"' % (cmd, output)
	#print('😄 %s' % cmd)
	return cmd, output, linklistfile

def create_universal_execute_script_text(package_dir, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_file, product_name):
	archive_path = '%s/%s.xcarchive' % (package_dir, product_target_name)
	cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/lipo -create'
	for arch in archs:
		cmd = '%s \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s\"' % (cmd, project_name, product_target_name, arch, product_name)
	output = '%s/Products/Applications/%s/%s' % (archive_path, product_file, product_name)
	cmd = '%s -output \"%s\"' % (cmd, output)
	return cmd, None, output, None, None, None

def create_universal_appextension_script_text(package_dir, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_file, product_name):
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/lipo -create'
	for arch in archs:
		cmd = '%s \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s\"' % (cmd, project_name, product_target_name, arch, new_product_target_name)
	output = '%s/Products/Applications/%s.app/PlugIns/%s/%s' % (archive_path, new_target_name, product_file, new_product_target_name)
	cmd = '%s -output \"%s\"' % (cmd, output)
	return cmd, None, output, None, None, None

def is_embed_dylib(embed_dylibs, product_file):
	product_name = confuse_utils.get_file_name(product_file)
	for item in embed_dylibs:
		if item == product_name:
			return True
		if item.startswith('\"') and item.endswith('\"'):
			if item[1:-1] == product_name:
				return True
	return False

def create_universal_archive_script_text(build_settings, embed_dylibs, product_type, product_file, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_name):
	skip_install = confuse_utils.get_build_settings_value(build_settings, 'SKIP_INSTALL', True)
	cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/libtool'
	#is_embed = is_embed_dylib(embed_dylibs, product_file)
	if product_type == PRODUCT_TYPE_STATIC:
		cmd = '%s -static' % cmd
	else:
		cmd = '%s -dynamic' % cmd
	ext = confuse_utils.get_file_extension(product_file)
	full_product_name = product_file[0:-(len(ext) + 1)]
	for arch in archs:
		cmd = '%s \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.tmp.%s\"' % (cmd, project_name, product_target_name, arch, full_product_name, ext)

	if skip_install:
		output = '${UNINSTALLED_PRODUCTS_DIR}/%s.tmp.%s' % (full_product_name, ext)
	else:
		output = '${BUILT_PRODUCTS_DIR}/%s.tmp.%s' % (full_product_name, ext)
	cmd = '%s -o \"%s\"' % (cmd, output)
	return cmd, None, output, None, None, None

def is_embed_framework(embed_frameworks, product_file):
	product_name = confuse_utils.get_file_name(product_file)
	for item in embed_frameworks:
		if item == product_name:
			return True
		if item.startswith('\"') and item.endswith('\"'):
			if item[1:-1] == product_name:
				return True
	return False

def create_universal_framework_script_text(build_settings, embed_frameworks, package_dir, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_file, mach_o_type, product_name):
	skip_install = confuse_utils.get_build_settings_value(build_settings, 'SKIP_INSTALL', True)
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	cmd = '${DT_TOOLCHAIN_DIR}/usr/bin/lipo -create'
	removedirs = []
	#is_embed = is_embed_framework(embed_framework, project_file)
	for arch in archs:
		cmd = '%s \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s\"' % (cmd, project_name, product_target_name, arch, product_name)
	if mach_o_type == MACH_O_TYPE_DYNAMIC:
		output1 = '%s/Products/Applications/%s/Frameworks/%s/%s' % (archive_path, app_product_file, product_file, product_name)
		outputdir = '%s/Products/Applications/%s/Frameworks/%s' % (archive_path, app_product_file, product_file)
		#if not is_embed:
		#	output1 = None
		#	outputdir = None
		#print('😄:%s %s' % (skip_install, product_target_name))
		if skip_install == True:
			output2 = '${UNINSTALLED_PRODUCTS_DIR}/%s/%s' % (product_file, product_name)
			copydir = '${UNINSTALLED_PRODUCTS_DIR}/%s' % (product_file)
			removedirs.append('${UNINSTALLED_PRODUCTS_DIR}/iphoneos/%s' % (product_file))
		else:
			output2 = '${BUILT_PRODUCTS_DIR}/%s/%s' % (product_file, product_name)
			copydir = '${BUILT_PRODUCTS_DIR}/%s' % (product_file)
			removedirs.append('${BUILT_PRODUCTS_DIR}/iphoneos/%s' % (product_file))
	else:
		output1 = '${BUILT_PRODUCTS_DIR}/%s/%s' % (product_file, product_name)
		output2 = None
		outputdir = '${BUILT_PRODUCTS_DIR}/%s' % (product_file)
		copydir = None
		removedirs.append('${BUILT_PRODUCTS_DIR}/iphoneos/%s' % (product_file))
	cmd = '%s -output \"%s\"' % (cmd, output1)
	return cmd, outputdir, output1, copydir, output2, removedirs

def gen_exclude_link_filelist(build_settings, project_info, project_name, target_name, package_dir):
	global rename_confilict_source_file
	path = '%s/%s-%s.Exclude.LinkFileList' % (package_dir, project_name, target_name)
	target_info = get_target_info_by_name(project_info, target_name)
	source_files = target_info['source-files']
	files = []
	for types in source_files:
		for type, file_infos in list(types.items()):
			for file_info in file_infos:
				file_path = file_info['path']
				flags = file_info['flags']
				if flags & 2 == 0:
					full_file_name = confuse_utils.get_full_file_name(file_path)
					file_ext = confuse_utils.get_file_extension(full_file_name)
					if file_ext == 'xcdatamodeld':#coredata
						load_datamodeld(file_path, files)
						continue
					file_name = confuse_utils.get_file_name(file_path)
					object_file = file_name + '.o'
					if 'alias-path' in file_info:
						if rename_confilict_source_file:
							object_file = confuse_utils.get_file_name(file_info['alias-path']) + '.o'
					files.append(object_file)
	#gen_asset_symbols = confuse_utils.get_build_settings_value(build_settings, 'ASSETCATALOG_COMPILER_GENERATE_ASSET_SYMBOLS', 'NO')
	#if gen_asset_symbols == 'YES':
	#	files.append('GeneratedAssetSymbols.o')
	with open(path, 'w') as f:
		for file in files:
			f.write('%s\n' % file)
		f.close()

#<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
#<model type="com.apple.IDECoreDataModeler.DataModel" documentVersion="1.0" lastSavedToolsVersion="21513" systemVersion="21G115" minimumToolsVersion="Automatic" sourceLanguage="Swift" userDefinedModelVersionIdentifier="">
#   <entity name="NimA" representedClassName="NimA" syncable="YES" codeGenerationType="class">
#       <attribute name="propA" optional="YES" attributeType="Double" defaultValueString="0.0" usesScalarValueType="YES"/>
#        <attribute name="propB" optional="YES" attributeType="String"/>
#    </entity>
#</model>
#
#NimA+CoreDataClass.o
#NimA+CoreDataProperties.o
#MyTestData+CoreDataModel.o
#
#
def load_datamodeld(file_path, files):
	filename = confuse_utils.get_file_name(file_path)
	model_file = '%s/%s.xcdatamodel/contents' %(file_path, filename)
	if os.path.exists(model_file):
		files.append('%s+CoreDataModel.o' % filename)
		with open(model_file, 'r') as fin:
			dom = xml.dom.minidom.parse(fin)
			fin.close()
			model_ele = dom.documentElement
			for entity in model_ele.childNodes:
				if entity.nodeName == 'entity':
					class_name = entity.getAttribute('name')
					files.append('%s+CoreDataClass.o' % class_name)
					files.append('%s+CoreDataProperties.o' % class_name)

def gen_include_link_filelist(build_settings, project_info, project_name, target_name, package_dir, exclude_files, exclude_source_files, mach_o_type, version_system, product_name):
	global rename_confilict_source_file
	path = '%s/%s-%s.LinkFileList' % (package_dir, project_name, target_name)
	target_info = get_target_info_by_name(project_info, target_name)
	source_files = target_info['source-files']
	files = []
	for types in source_files:
		for type, file_infos in list(types.items()):
			for file_info in file_infos:
				file_path = file_info['path']
				full_file_name = confuse_utils.get_full_file_name(file_path)
				file_ext = confuse_utils.get_file_extension(full_file_name)
				if file_ext == 'xcdatamodeld':#coredata
					load_datamodeld(file_path, files)
					continue
				if full_file_name in exclude_source_files:
					continue
				if (full_file_name in exclude_files) == False:
					file_name = confuse_utils.get_file_name(file_path)
					object_file = file_name + '.o'
					if 'alias-path' in file_info:
						if rename_confilict_source_file:
							object_file = confuse_utils.get_file_name(file_info['alias-path']) + '.o'
					files.append(object_file)
	if version_system == 'apple-generic':
		files.append('%s_vers.o' % product_name)
	#gen_asset_symbols = confuse_utils.get_build_settings_value(build_settings, 'ASSETCATALOG_COMPILER_GENERATE_ASSET_SYMBOLS', 'NO')
	#if gen_asset_symbols == 'YES':
	#	files.append('GeneratedAssetSymbols.o')
	#print('😊:%s' % files)
	with open(path, 'w') as f:
		for file in files:
			f.write('%s\n' % file)
		f.close()

def gen_source_link_filelist(work_dir, bundle_id, build_settings, project_info, project_name, target_name, package_dir, exclude_files, exclude_source_files):
	global rename_confilict_source_file
	path = '%s/%s-%s.SourceMap.LinkFileList' % (package_dir, project_name, target_name)
	target_info = get_target_info_by_name(project_info, target_name)
	source_files = target_info['source-files']
	files = {}
	for types in source_files:
		for type, file_infos in list(types.items()):
			for file_info in file_infos:
				full_file_name = confuse_utils.get_full_file_name(file_info['path'])
				if full_file_name in exclude_source_files:
					continue
				if (full_file_name in exclude_files) == False:
					file_name = confuse_utils.get_file_name(file_info['path'])
					if 'alias-path' in file_info:
						if rename_confilict_source_file:
							files[file_name + '.o'] = file_info['alias-path']
						else:
							files[file_name + '.o'] = file_info['path']
					else:
						files[file_name + '.o'] = file_info['path']
	#gen_asset_symbols = confuse_utils.get_build_settings_value(build_settings, 'ASSETCATALOG_COMPILER_GENERATE_ASSET_SYMBOLS', 'NO')
	#if gen_asset_symbols == 'YES':
	#	files.append('GeneratedAssetSymbols.o')
	with open(path, 'w') as f:
		for key,value in list(files.items()):
			f.write('%s=%s\n' % (key, value))
		f.close()


def append_once(arr, item):
	if item in arr:
		return
	arr.append(item)

def is_system_library(sdk_root, library):
	dirnames = ['/usr/lib', '/usr/lib/swift']
	for name in dirnames:
		filepath = '%s%s/lib%s.tbd' % (sdk_root, name, library)
		if os.path.exists(filepath):
			return True
		filepath = '%s%s/lib%s.dylib' % (sdk_root, name, library)
		if os.path.exists(filepath):
			return True
	return False

def is_unity_game_assembly(target_name):
	return target_name == 'GameAssembly'

def get_link_frameworks_and_libraries(sdk_root, package_dir, frameworks, libraries, library_search_paths):
	link_frameworks = []
	link_libraries = []
	profile = load_workspace_profile(package_dir)
	product_frameworks = []
	product_libraries = []
	for project in profile['projects']:
		products = project['products']
		for target_name, product_file_info in list(products.items()):
			if is_skip_product_archive(target_name):
				continue
			product_file = product_file_info['name']
			file_ext = confuse_utils.get_file_extension(product_file)
			if file_ext == 'a' or file_ext == 'dylib':
				product_libraries.append(product_file[3:-(len(file_ext) + 1)])
			pass

	for framework in frameworks:
		append_once(link_frameworks, framework)

	for library in libraries:
		found = False
		for item in product_libraries:
			if item == library:
				found = True
				break
		if found == False:
			append_once(link_libraries, library)
		else:
			append_once(link_libraries, library + '.tmp')
	
	custom_libraries = []
	for library in link_libraries:
		if not is_system_library(sdk_root, library):
			custom_libraries.append(library)
	return link_frameworks, link_libraries, custom_libraries

def link_static_library_dynamic_depend_options(mach_o_type, link_frameworks, link_libraries, result_link_frameworks, result_link_libraies, framework_search_paths, library_search_paths):
	for link_framework in link_frameworks:
		options = get_product_file_link_options(link_framework + ".framework")
		if options != None:
			temp_frameworks = options['frameworks']
			temp_libraries = options['libraries']
			dependencies = options['dependencies']
			#静态库
			if options['macho-type'] != MACH_O_TYPE_DYNAMIC:
				for temp_framework in temp_frameworks:
					append_once(result_link_frameworks, temp_framework)
				for temp_library in temp_libraries:
					append_once(result_link_libraies, temp_library)
				temp_framework_search_paths = options['framework-search-paths']
				for temp_framework_search_path in temp_framework_search_paths:
					append_once(framework_search_paths, temp_framework_search_path)
				library_search_paths = options['framework-search-paths']
				for temp_framework_search_path in temp_framework_search_paths:
					append_once(framework_search_paths, temp_framework_search_path)
				for depend in dependencies:
					#print('😄:depend %s' % depend)
					depend_options = get_product_file_link_options(depend)
					if depend_options['macho-type'] != MACH_O_TYPE_DYNAMIC:
						link_static_library_dynamic_depend_options(depend_options['macho-type'], depend_options['frameworks'], depend_options['libraries'], link_frameworks, link_libraries, framework_search_paths, library_search_paths)
					else:
						#把依赖的库加进来
						if depend.endswith('.framework'):
							append_once(result_link_frameworks, depend[0:-10])
						if depend.endswith('.a'):
							append_once(result_link_libraries, depend[0:-2])
			else:
				link_static_library_dynamic_depend_options(options['macho-type'], temp_frameworks, temp_libraries, link_frameworks, link_libraries, framework_search_paths, library_search_paths)

def get_product_file_by_target(project, target_object):
	productReference = target_object['productReference']
	fileRef = project.get_object(productReference)
	if fileRef == None:
		return None
	return fileRef['path']

def get_input_file_list(input_files, arch):
	if input_files == None:
		return None
	ret = []
	for input_file in input_files:
		if arch in input_file:
			ret.append(input_file[arch])
	return ret

def get_exclude_file_list(exclude_input_files, arch):
	if exclude_input_files == None:
		return None
	ret = []
	for exclude_input_file in exclude_input_files:
		if arch in exclude_input_file:
			ret.append(exclude_input_file[arch])
	return ret

def has_cpp_file(project_info, target_name):
	target_info = get_target_info_by_name(project_info, target_name)
	source_files = target_info['source-files']
	for types in source_files:
		for type, file_infos in list(types.items()):
			for file_info in file_infos:
				flags = file_info['flags']
				#if flags & 2:
				file_type = confuse_utils.get_file_extension(file_info['path'])
				if file_type == 'mm' or file_type == 'cpp':
					return True
	return False
	
def has_swift_file(project_info, target_name):
	target_info = get_target_info_by_name(project_info, target_name)
	source_files = target_info['source-files']
	for types in source_files:
		for type, file_infos in list(types.items()):
			for file_info in file_infos:
				flags = file_info['flags']
				#if flags & 2:
				file_type = confuse_utils.get_file_extension(file_info['path'])
				if file_type == 'swift':
					return True
	return False

product_file_link_options_map = {}

def add_product_file_link_options(project_info, product_target_name, product_file, mach_o_type, frameworks, libraries, is_main_target, framework_search_paths, library_search_paths):
	target_info = get_target_info_by_name(project_info, product_target_name)
	project_name = project_info['name']
	target_dependencies = target_info['dependencies']
	dependencies = []
	for target_dependencie in target_dependencies:
		depend_project = target_dependencie['project']
		depend_target = target_dependencie['target']
		project_infos = workspace_profile['projects']
		for project_info in project_infos:
			if project_info['name'] == depend_project:
				products = project_info['products']
				if depend_target in products:
					product_info = products[depend_target]
					append_once(dependencies, product_info['name'])
					break

	product_file_link_options_map[product_file] = {'macho-type' : mach_o_type, 'dependencies' : dependencies, 'frameworks' : frameworks, 'libraries' : libraries, 'is-main-target' : is_main_target, 'framework-search-paths' : framework_search_paths, 'library-search-paths' : library_search_paths}
	#print('😄%s=%s' % (product_file,product_file_link_options_map[product_file]))

def get_product_file_link_options(product_file):
	if product_file in product_file_link_options_map:
		return product_file_link_options_map[product_file]
	return None
	
def gen_link_options_map_file(package_dir):
	filename = '%s/workspace.linkmap' % (package_dir)
	with open(filename, 'w') as f:
		#print product_file_link_options_map
		f.write(json.dumps(product_file_link_options_map,ensure_ascii=False))
		f.close()
	pass

def check_framework_exists(sdk_root, framework_search_paths, framework):
	filepath = '%s/System/Library/Frameworks/%s.framework' % (sdk_root, framework)
	if os.path.exists(filepath):
		return True
	for framework_search_path in framework_search_paths:
		filepath = '%s/%s.framework' % (framework_search_path, framework)
		if os.path.exists(filepath):
			return True
	return False

def check_library_exists(sdk_root, library_search_paths, library):
	if library.startswith('/'):
		return os.path.exists(filepath)
	dirnames = ['/usr/lib', '/usr/lib/swift']
	for name in dirnames:
		filepath = '%s%s/lib%s.tbd' % (sdk_root, name, library)
		if os.path.exists(filepath):
			return True
		filepath = '%s%s/lib%s.dylib' % (sdk_root, name, library)
		if os.path.exists(filepath):
			return True
	for library_search_path in library_search_paths:
		filepath = '%s/lib%s.a' % (library_search_path, library)
		if os.path.exists(filepath):
			return True
		filepath = '%s/lib%s.dylib' % (library_search_path, library)
		if os.path.exists(filepath):
			return True
	return False

target_history = {}
new_symbol_target_caches = {}
new_symbol_product_target_caches = {}

main_target_name = None
app_product_file = None

def find_library(library_search_paths, file_name):
	for library_search_path in library_search_paths:
		path = '%s/%s' % (library_search_path, file_name)
		if os.path.exists(path):
			print('found %s' % path)
			return path
	return None


product_confuse_configs = {}
product_archive_files = []

def is_skip_product_archive(target_name):
	if target_name in product_confuse_configs.keys():
		info = product_confuse_configs[target_name]
		if 'confuse-type' in info.keys():
			if info['confuse-type'] != 'inner':
				return True
	return False

def get_product_confuse_files():
	return product_archive_files

def create_target_script_cmds(project, envs, project_info, script_dir, work_dir, bundle_id, package_dir, cache_dir, work_space_dir, archive_settings_file, target_name, archs, configure, product_files, preprcess_cmds, confuse_cmds, link_cmds, checkcache_cmds, input_files, exclude_input_files, product_target_name):
	if target_name in new_symbol_target_caches:
		new_target_name = new_symbol_target_caches[target_name]
	else:
		new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target', False)
		new_symbol_target_caches[target_name] = new_target_name
	
	if product_target_name in new_symbol_product_target_caches:
		new_product_target_name = new_symbol_product_target_caches[product_target_name]
	else:
		new_product_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, product_target_name, 'target', False)
		new_symbol_product_target_caches[product_target_name] = new_product_target_name

	project_file = project_info['path']
	project_name = project_info['name']
	#print('😊 target_name:%s new_target_name:%s' % (product_target_name, new_product_target_name))

	target_object = get_target_by_name(project, project_name, product_target_name)
	if target_object == None:
		print('target name %s not found.' % product_target_name)
		return
	product_file = get_product_file_by_target(project, target_object)

	if product_file == None:
		print('target name %s not found product file.' % product_target_name)
		return

	if product_target_name == main_target_name:
		global app_product_file
		app_product_file = product_file

	target_history_key = '%s.%s' % (project_name, product_target_name) 
	if target_history_key in target_history:
		#print('target %s is exists.' % target_history_key)
		return
	target_history[target_history_key] = True

	depend_input_files = []
	depend_exclude_input_files = []
	create_depend_script_cmds(project, envs, script_dir, work_dir, bundle_id, package_dir, cache_dir, work_space_dir, archive_settings_file, project_file, project_info, target_name, archs, configure, product_files, preprcess_cmds, confuse_cmds, link_cmds, depend_input_files, depend_exclude_input_files,  product_target_name)

	product_type = target_object['productType']
	print('##############')
	print('🎯 targetName:%s' % product_target_name)

	if is_skip_product_archive(product_target_name):
		print('target:%s 被直接忽略了' % product_target_name)
		return
	
	skip = True
	product_types = [PRODUCT_TYPE_APPLICATION, PRODUCT_TYPE_APPEXTENSION, PRODUCT_TYPE_STATIC, PRODUCT_TYPE_DYNAMIC, PRODUCT_TYPE_FRAMEWORK]
	if product_type in product_types:
		skip = False
	if skip:
		print('target name %s skip create script.' % product_target_name)
		return

	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, use_cache_file=False, use_archive_xcconfig=True)
	product_file = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')
	if product_files != None:
		product_files.append(product_file)
	print('product-file:%s' % product_file)
	project_name = confuse_utils.get_file_name(project_name)
	gen_exclude_link_filelist(build_settings, project_info, project_name, product_target_name, package_dir)

	exclude_source_files = confuse_utils.get_build_settings_value(build_settings, 'EXCLUDED_SOURCE_FILE_NAMES', [], False)

	exclude_files = {}
	files = get_exclude_source_file_names(build_settings)
	for file in files:
		if file.startswith('\'') and file.endswith('\''):
			exclude_files[file[1:-2]] = True
		else:
			exclude_files[file] = True
	mach_o_type = confuse_utils.get_build_settings_value(build_settings, 'MACH_O_TYPE', '')
	product_name = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_NAME', new_product_target_name)
	version_system = confuse_utils.get_build_settings_value(build_settings, 'VERSIONING_SYSTEM', '')

	gen_include_link_filelist(build_settings, project_info, project_name, product_target_name, package_dir, exclude_files, exclude_source_files, mach_o_type, version_system, product_name)
	gen_source_link_filelist(work_dir, bundle_id, build_settings, project_info, project_name, product_target_name, package_dir, exclude_files, exclude_source_files)

	framework_search_paths = confuse_utils.get_framework_search_paths_settings_value(build_settings)
	library_search_paths = confuse_utils.get_library_search_paths_settings_value(build_settings)
	other_flags = confuse_utils.get_other_ldflags_settings_value(build_settings)
	runtime_search_paths = confuse_utils.get_runtime_search_paths(build_settings)
	sdk_root = confuse_utils.get_build_settings_value(build_settings, 'SDKROOT', '')
	built_products_dir = confuse_utils.get_build_settings_value(build_settings, 'BUILT_PRODUCTS_DIR', '')
	#new_built_products_dir = confuse_utils.replace_text_vars(envs, '${OBJROOT}/ArchiveIntermediates/%s/BuildProductsPath/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}' % (target_name))
	print('product-type:%s' % mach_o_type)
	#print('product-target-name:%s' % product_target_name)
	print('built_products_dir:%s' % built_products_dir)
	#print('new_built_products_dir:%s' %  new_built_products_dir)
	#print('path:%s' % confuse_utils.replace_text_vars(envs, '${OBJROOT}/UninstalledProducts/${PLATFORM_NAME}'))
	#for i in range(0, len(framework_search_paths)):
	#	framework_search_path = framework_search_paths[i]
	#	if framework_search_path.startswith(built_products_dir):
	#		framework_search_paths[i] = new_built_products_dir + framework_search_path[len(built_products_dir):]

	#for i in range(0, len(library_search_paths)):
	#	library_search_path = library_search_paths[i]
	#	if library_search_path.startswith(built_products_dir):
	#		library_search_paths[i] = new_built_products_dir + library_search_path[len(built_products_dir):]

	framework_search_paths.append(confuse_utils.replace_text_vars(envs, '${UNINSTALLED_PRODUCTS_DIR}'))
	library_search_paths.append(confuse_utils.replace_text_vars(envs, '${UNINSTALLED_PRODUCTS_DIR}'))
	#framework_search_paths.append(new_built_products_dir)
	#library_search_paths.append(new_built_products_dir)
	#print 'framework_search_paths %s' % framework_search_paths
	#print 'library_search_paths %s' % library_search_paths
	#print 'runtime_search_paths %s' % runtime_search_paths
	#print 'build settings %s' % (build_settings)

	frameworks = []
	embed_frameworks = []
	embed_dylibs = []
	libraries = []
	frameworks_build_phase = []
	embed_frameworks_build_phrase = []

	get_frameworks_build_phase(project, target_object, frameworks_build_phase)

	#print frameworks_build_phase
	for framework_build_phase in frameworks_build_phase:
		file_ref = project.get_object(framework_build_phase)
		if not hasattr(file_ref, 'path'):
			continue
		file_path = file_ref['path']
		file_name = file_path[file_path.rfind('/') + 1:]
		file_ext = file_name[file_name.rfind('.') + 1:]
		if file_ext == 'framework':
			frameworks.append(file_name[:-(len(file_ext) + 1)])
		else:
			if file_name.startswith('lib'):
				append_once(libraries, file_name[3:-(len(file_ext) + 1)])
			else:
				found_path = find_library(library_search_paths, file_name)
				if found_path != None:
					append_once(libraries, found_path)
	print('build phrase(framework):%s' % frameworks)
	print('build phrase(libarries):%s' % libraries)

	get_embed_frameworks_build_phase(project, target_object, embed_frameworks_build_phrase)

	for framework_build_phase in embed_frameworks_build_phrase:
		file_ref = project.get_object(framework_build_phase)
		if not hasattr(file_ref, 'path'):
			continue
		file_path = file_ref['path']
		file_name = file_path[file_path.rfind('/') + 1:]
		file_ext = file_name[file_name.rfind('.') + 1:]
		if file_ext == 'framework':
			embed_frameworks.append(file_name[:-(len(file_ext) + 1)])
		elif file_ext == 'dylib':
			if file_name.startswith('lib'):
				append_once(embed_dylibs, file_name[:-(len(file_ext) + 1)])
			else:
				found_path = find_library(library_search_paths, file_name)
				if found_path != None:
					append_once(embed_dylibs, found_path)

	print('embed framework:%s' % embed_frameworks)
	print('embed dylib:%s' % embed_dylibs)
	#避免ccache导致的问题，需要默认加载UIKit,Funcation
	if ccache_enable:
		import_frameworks = ['Foundation', 'UIKit', 'QuartzCore', 'OpenGLES', 'CoreImage']
		for import_framework in import_frameworks:
			append_once(frameworks, import_framework)
	
	if require_ui_kit:
		import_frameworks = ['Foundation', 'UIKit', 'QuartzCore', 'OpenGLES', 'CoreImage']
		for import_framework in import_frameworks:
			append_once(frameworks, import_framework)

	print('other-flags:%s' % other_flags)
	other_frameworks = []
	other_libraries = []
	other_flags = filter_frameworks_and_libraries_and_search_paths(other_flags, other_frameworks, other_libraries, framework_search_paths, library_search_paths)
	archive_file = product_file

	print('other-frameworks:%s' % other_frameworks)
	print('other-libraries:%s' % other_libraries)
	for framework in other_frameworks:
		if check_framework_exists(sdk_root, framework_search_paths, framework):
			append_once(frameworks, framework)
		else:
			print('warning:%s not exists.' % framework)

	for library in other_libraries:
		if check_library_exists(sdk_root, library_search_paths, library):
			append_once(libraries, library)
		else:
			print('warning:%s not exists.' % library)

	if product_type == PRODUCT_TYPE_APPLICATION or product_type == PRODUCT_TYPE_APPEXTENSION:
		archive_file = None

	#print ('target:%s' % product_target_name)
	#print ('libraries:%s' % libraries)
	#print 'frameworks:%s' % frameworks
	#print product_file_link_options_map
	add_product_file_link_options(project_info, product_target_name,product_file, mach_o_type, frameworks, libraries, product_target_name == target_name, framework_search_paths, library_search_paths)
	#print product_file_link_options_map

	has_cpp = has_cpp_file(project_info, product_target_name)
	has_swift = has_swift_file(project_info, product_target_name)
	#print('😊:%s has_swift:%s' % (product_target_name, has_swift))

	#preprocess
	cmd_group = []
	preprcess_cmds.append(cmd_group)
	cmd_group.append('echo \"preprocess %s %s %s\"' % (project_name, product_target_name, archs))
	for arch in archs:
		if configure == 'Release':
			input_files[arch] = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList' % (project_name, product_target_name, arch, product_name)
		else:
			input_files[arch] = '${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/%s.LinkFileList.tmp' % (project_name, product_target_name, arch, product_name)
		exclude_input_files[arch] = '%s/%s-%s.Exclude.LinkFileList' % (package_dir, project_name, product_target_name)
		
		if configure == 'Release' and exchange_object_file == True:
			cmd_group.append('@python restore(\"%s\")' % input_files[arch])
		cmd = create_rewriter_macho_script_text(configure, archive_file, project, script_dir, work_dir, cache_dir, bundle_id, package_dir, work_space_dir, archive_settings_file, project_name, target_name, new_target_name, arch, framework_search_paths, library_search_paths, frameworks, libraries, embed_frameworks, 'preprocess', None, None, product_target_name, new_product_target_name, product_name, has_cpp, has_swift)
		cmd_group.append(cmd)

	cmd_group = []
	confuse_cmds.append(cmd_group)
	cmd_group.append('echo \"confuse %s %s %s\"' % (project_name, product_target_name, archs))

	#confuse
	for arch in archs:
		#cmd_group.append('rm -rf \"${OBJROOT}/%s.build/${CONFIGURATION}${EFFECTIVE_PLATFORM_NAME}/%s.build/Objects-normal/%s/*.o.tmp\"' % (project_name, product_target_name, arch))
		input_file_list = get_input_file_list(depend_input_files, arch)
		exclude_input_file_list = get_exclude_file_list(depend_exclude_input_files, arch)

		cmd = create_rewriter_macho_script_text(configure, archive_file, project, script_dir, work_dir, cache_dir, bundle_id, package_dir, work_space_dir, archive_settings_file, project_name, target_name, new_target_name, arch, framework_search_paths, library_search_paths, frameworks, libraries, embed_frameworks, 'confuse', input_file_list, exclude_input_files, product_target_name, new_product_target_name, product_name, has_cpp, has_swift)
		cmd_group.append(cmd)

	#checkcache
	if checkcache_cmds != None:
		for arch in archs:
			input_file_list = get_input_file_list(depend_input_files, arch)
			exclude_input_file_list = get_exclude_file_list(depend_exclude_input_files, arch)

			cmd = create_rewriter_macho_script_text(configure, archive_file, project,  script_dir, work_dir, cache_dir, bundle_id, package_dir, work_space_dir, archive_settings_file, project_name, target_name, new_target_name, arch, framework_search_paths, library_search_paths, frameworks, libraries, embed_frameworks, 'checkcache', input_file_list, exclude_input_files, product_target_name, new_product_target_name, product_name, has_cpp, has_swift)
			cmd_group = []
			checkcache_cmds.append(cmd_group)
			cmd_group.append('echo \"checkcache\"')
			cmd_group.append(cmd)

	link_frameworks, link_libraries, custom_libraries = get_link_frameworks_and_libraries(sdk_root, package_dir, frameworks, libraries, library_search_paths)
	if mach_o_type == MACH_O_TYPE_EXECUTE:
		link_static_library_dynamic_depend_options(mach_o_type, array_copy(link_frameworks), array_copy(link_libraries), link_frameworks, link_libraries, framework_search_paths, library_search_paths)
		#print('😄1.:%s' % (link_frameworks))
		#print('😄2.:%s' % (link_libraries))

	print('custom-libraries:%s' % custom_libraries)
	#link
	cmd_group = []
	link_cmds.append(cmd_group)
	cmd_group.append('echo \"link binary %s %s %s\"' % (project_name, product_target_name, archs))
	for arch in archs:
		if product_type == PRODUCT_TYPE_APPLICATION:
			cmd,output,linklistfile = create_link_execute_script_text(package_dir, configure, build_settings, arch, link_frameworks, link_libraries, framework_search_paths, library_search_paths, runtime_search_paths, other_flags, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_name, has_cpp, has_swift)
		elif product_type == PRODUCT_TYPE_APPEXTENSION:
			cmd,output,linklistfile = create_link_appextension_script_text(package_dir, configure, build_settings, arch, link_frameworks, link_libraries, framework_search_paths, library_search_paths, runtime_search_paths, other_flags, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_name, has_cpp, has_swift)
		elif product_type == PRODUCT_TYPE_FRAMEWORK:
			cmd,output,linklistfile = create_link_framework_script_text(package_dir, configure, build_settings, arch, link_frameworks, link_libraries, custom_libraries, framework_search_paths, library_search_paths, runtime_search_paths, other_flags, project_name, target_name, new_target_name, product_target_name, new_product_target_name, mach_o_type, product_name, has_cpp, has_swift)
		else:
			cmd,output,linklistfile = create_link_archive_script_text(package_dir, configure, build_settings, product_type, product_file, arch, link_frameworks, link_libraries, custom_libraries, framework_search_paths, library_search_paths, other_flags, project_name, target_name, product_target_name, new_product_target_name, mach_o_type, product_name, has_cpp, has_swift)
		if len(output) and output != '/':
			cmd_group.append('rm -rf \"%s\"' % (output))

		if configure == 'Release' and exchange_object_file == True:
			cmd_group.append('@python exchange(\"%s\")' % linklistfile)
		cmd_group.append(cmd)
		cmd = '@python if os.path.exists(\'%s\') == False:\n\tprint(\'not found file %s\')\n\tsys.exit(1)' % (output, output)
		cmd_group.append(cmd)
	
	#print 'product_type %s' % product_type
	#lipo
	cmd_group = []
	link_cmds.append(cmd_group)
	cmd_group.append('echo \"create universal binary %s %s %s\"' % (project_name, product_target_name, archs))
	if product_type == PRODUCT_TYPE_APPLICATION:
		cmd,outputdir,output,copydir,copyoutput,removefiles = create_universal_execute_script_text(package_dir, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_file, product_name)
	elif product_type == PRODUCT_TYPE_APPEXTENSION:
		cmd,outputdir,output,copydir,copyoutput,removefiles = create_universal_appextension_script_text(package_dir, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_file, product_name)
	elif product_type == PRODUCT_TYPE_FRAMEWORK:
		cmd,outputdir,output,copydir,copyoutput,removefiles = create_universal_framework_script_text(build_settings, embed_frameworks, package_dir, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_file, mach_o_type, product_name)
	elif product_type == PRODUCT_TYPE_STATIC or product_type == PRODUCT_TYPE_DYNAMIC:
		cmd,outputdir,output,copydir,copyoutput,removefiles = create_universal_archive_script_text(build_settings, embed_dylibs, product_type, product_file, archs, project_name, target_name, new_target_name, product_target_name, new_product_target_name, product_name)

	if removefiles != None:
		for removefile in removefiles:
			cmd1 = 'rm -rf \"%s\"\n' % (confuse_utils.pstr(removefile))
			cmd_group.append(cmd1)
	
	if outputdir != None:
		cmd1 = '@python if os.path.islink(\'%s\'):\n\tos.remove(\'%s\')\n' % (confuse_utils.pstr(outputdir), confuse_utils.pstr(outputdir))
		cmd_group.append(cmd1)
		cmd1 = '@python if os.path.exists(\'%s\') == False:\n\tos.makedirs(\'%s\')\n' % (confuse_utils.pstr(outputdir), confuse_utils.pstr(outputdir))
		cmd_group.append(cmd1)

	if copydir != None:
		cmd1 = '@python if os.path.islink(\'%s\'):\n\tos.remove(\'%s\')\n' % (confuse_utils.pstr(copydir), confuse_utils.pstr(copydir))
		cmd_group.append(cmd1)
		cmd1 = '@python if os.path.exists(\'%s\') == False:\n\tos.makedirs(\'%s\')\n' % (confuse_utils.pstr(copydir), confuse_utils.pstr(copydir))
		cmd_group.append(cmd1)

	if len(output) and output != '/':
		cmd_group.append('rm -rf \"%s\"' % (output))

	if copyoutput != None and len(copyoutput) and copyoutput != '/':
		cmd_group.append('rm -rf \"%s\"' % (copyoutput))

	cmd_group.append(cmd)
	cmd = '@python if os.path.exists(\'%s\') == False:\n\tprint(\'not found file %s\')\n\tsys.exit(1)' % (confuse_utils.pstr(output), confuse_utils.pstr(output))
	cmd_group.append(cmd)

	if copyoutput != None:
		cmd_group.append('cp -rf \"%s\" \"%s\"' % (confuse_utils.pstr(output), confuse_utils.pstr(copyoutput)))

depend_project_load_history = {}

def create_depend_script_cmds(project, envs, script_dir, work_dir, bundle_id, package_dir, cache_dir, work_space_dir, archive_settings_file, project_file, project_info, target_name, archs, configure, product_files, preprcess_cmds, confuse_cmds, link_cmds, depend_input_files, depend_exclude_input_files, product_target_name):
	depend_project_infos = []
	get_depend_projects(depend_project_infos, package_dir, project_file, product_target_name)

	temp_cmds = []
	#depend_link_cmds = []
	depend_targets = []
	get_depend_targets(depend_targets, project_info, product_target_name)
	for depend_target in depend_targets:
		depend_target_name = depend_target['target']
		input_files = {}
		exclude_input_files = {}
		create_target_script_cmds(project, envs, project_info, script_dir, work_dir, bundle_id, package_dir, cache_dir, work_space_dir, archive_settings_file, target_name, archs, configure, product_files, temp_cmds, confuse_cmds, link_cmds, None, input_files, exclude_input_files, depend_target_name)	
		depend_input_files.append(input_files)
		depend_exclude_input_files.append(exclude_input_files)

	global depend_project_load_history
	#开始计算target
	for depend_project_info in depend_project_infos:
		project_file = depend_project_info['project_file']
		depend_project_info = depend_project_info['project_info']
		targets = depend_project_info['targets']
		pbxprojfile = '%s/project.pbxproj' % project_file
		if pbxprojfile in depend_project_load_history:
			#不会重复创建
			continue
		depend_project_load_history[pbxprojfile] = True
		#print('%s' % pbxprojfile)
		project = XcodeProject.load(pbxprojfile)
		for depend_target in targets:
			depend_target_name = depend_target['name']
			input_files = {}
			exclude_input_files = {}
			create_target_script_cmds(project, envs, depend_project_info, script_dir, work_dir, bundle_id, package_dir, cache_dir, work_space_dir, archive_settings_file, target_name, archs, configure, product_files, temp_cmds, confuse_cmds, link_cmds, None, input_files, exclude_input_files, depend_target_name)	
			depend_input_files.append(input_files)
			depend_exclude_input_files.append(exclude_input_files)

	for cmd in temp_cmds:
		preprcess_cmds.append(cmd)

def cmd_format(envs, cmd):
	cmd_str = confuse_utils.replace_text_vars(envs, cmd)
	cmd_str = cmd_str.replace('\'', '\\\'')
	cmd_str = cmd_str.replace('\"', '\\\"')
	cmd_str = cmd_str.replace('\n', '\\n')
	return cmd_str


def gen_group_def(envs, cmds, pos, group_defs, python_defs, child_pos = None):
	for i in range(0, len(cmds)):
		cmd = cmds[i]
		if type(cmd) == list:
			gen_group_def(envs, cmd, pos, group_defs, python_defs, i)
		else:
			if cmd.startswith('@python '):
				gen_python_def(envs, cmd, pos, python_defs, child_pos, i)

	if child_pos == None:
		group_defs.append('def cmd_group_%d():' % pos)
	else:
		group_defs.append('def cmd_group_%d_%d():' % (pos, child_pos))
	group_defs.append('\tcmds = [')
	for i in range(0, len(cmds)):
		cmd = cmds[i]
		if type(cmd) == str:
			if cmd.startswith('@python '):
				if child_pos == None:
					group_defs.append('\tpython_script_%d_%d, ' % (pos, i))
				else:
					group_defs.append('\tpython_script_%d_%d_%d, ' % (pos, child_pos, i))
			else:
				group_defs.append('\t"%s", ' % cmd_format(envs, cmd))
		else:
			group_defs.append('\tcmd_group_%d_%d, ' % (pos, i))
	group_defs.append('\t]')
	group_defs.append('\texec_cmd_list(cmds, save_pos = False)')
	group_defs.append('pass')
	pass

def gen_python_def(envs, cmd, pos, python_defs, child_pos, script_pos):
	if pos != None and child_pos != None:
		python_defs.append('def python_script_%d_%d_%d():' % (pos, child_pos, script_pos))
	elif pos != None:
		python_defs.append('def python_script_%d_%d():' % (pos, script_pos))
	else:
		python_defs.append('def python_script_%d():' % (script_pos))
	cmd_str = confuse_utils.replace_text_vars(envs, cmd[8:])
	lines = cmd_str.split('\n')
	for line in lines:
		python_defs.append('\t%s' % line)
	pass

def create_script_text(cmds, envs, project, project_info, project_file, work_dir, script_dir, bundle_id, package_dir, cache_dir, work_space_dir, archive_settings_file, target_name, archs, configure, workspace_dir):
	preprcess_cmds = []
	confuse_cmds = []
	checkcache_cmds = []
	link_cmds = []
	lipo_cmds = []

	if script_dir == None:
		script_dir = '/Users/carb/Documents/myprojects/iOS-artifact/resource/projectmanager/other/script'

	preprocess_archive_cmds = []
	confuse_archive_cmds = []
	link_archive_cmds = []
	create_preprocess_archives_cmds(preprocess_archive_cmds, configure, archs, work_dir, bundle_id, cache_dir, package_dir, workspace_dir, archive_settings_file, script_dir)
	create_confuse_archives_cmds(confuse_archive_cmds, configure, archs, work_dir, bundle_id, cache_dir, package_dir, workspace_dir, archive_settings_file, script_dir)
	create_link_archives_cmds(link_archive_cmds, configure, archs, work_dir, bundle_id, package_dir, workspace_dir, archive_settings_file)

	input_files = {}
	exclude_input_files = {}
	product_files = []
	create_target_script_cmds(project, envs, project_info, script_dir, work_dir, bundle_id, package_dir, cache_dir, work_space_dir, archive_settings_file, target_name, archs, configure, product_files, preprcess_cmds, confuse_cmds, link_cmds, checkcache_cmds, input_files, exclude_input_files, target_name)

	cmd = 'cd \"%s\"' % project._source_root
	cmds.append(cmd)

	product_archive_file = '%s/product_archive_files.txt' % (package_dir)
	#生成所有product files
	cmd_group = []
	for i in range(0, len(product_files)):
		product_file = product_files[i]
		if product_file.endswith('.app'):
			continue
		if i != 0:
			cmd = 'echo %s >> %s' % (product_file, product_archive_file)
		else:
			cmd = 'echo %s > %s' % (product_file, product_archive_file)
		cmd_group.append(cmd)
	
	for cmd in preprocess_archive_cmds:
		cmds.append(cmd)

	cmds.append(cmd_group)

	for cmd in preprcess_cmds:
		cmds.append(cmd)

	for cmd in checkcache_cmds:
		cmds.append(cmd)

	for cmd in confuse_archive_cmds:
		cmds.append(cmd)

	for cmd in confuse_cmds:
		cmds.append(cmd)

	for cmd in link_archive_cmds:
		cmds.append(cmd)

	for cmd in link_cmds:
		cmds.append(cmd)

def make_archive_xcconfig(package_dir, target_name, configure):
	global workspace_file
	envs = confuse_utils.get_workspace_build_settings(workspace_file, target_name, configure)
	file_name = '%s/archive.%s.xcconfig' % (package_dir, configure)
	with open(file_name, 'w') as f:
		pp = '%s/ArchiveIntermediates/%s/BuildProductsPath' % (envs['TEMP_ROOT'], target_name)
		envs['BUILD_DIR'] = pp
		envs['SYMROOT'] = pp
		keys = ['TEMP_ROOT', 'OBJROOT', 'BUILD_DIR', 'SYMROOT']
		for key in keys:
			f.write('%s = %s\n' % (key, envs[key]))
		f.close()

def get_product_build_file_path(work_dir, bundle_id, configure, workspace_profile, target_name):
	projects = workspace_profile['projects']
	for project in projects:
		project_file = project['path']
		products = project['products']
		if target_name in products:
			build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name, use_cache_file=False, use_archive_xcconfig=True)
			product_info = products[target_name]
			product_name = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')
			output_dir = confuse_utils.get_build_settings_value(build_settings, 'METAL_LIBRARY_OUTPUT_DIR', '')
			if product_name.endswith('.framework'):
				product_dir = output_dir[:output_dir.rfind('/')]
			else:
				product_dir = output_dir
			return product_dir + product_name
	return ''

def get_dict_value(map,key,defval):
	if key in map.keys():
		return map[key]
	return defval

def get_dict_value_str(map,key,defval):
	v = get_dict_value(map, key, defval)
	if isinstance(v, bool):
		if v:
			return 'true'
		return 'false'
	return '%s' % v

def load_product_confuse_configs(work_dir, bundle_id, configure, package_dir, workspace_profile):
	global product_confuse_configs
	global product_archive_files
	file_name = '%s/confuse_product_archive_configs.txt' % (package_dir)
	if not os.path.exists(file_name):
		return
	setting_configs = confuse_utils.read_settings_file(file_name)

	if 'targets' not in setting_configs:
		return
	targets = setting_configs['targets']
	for target in targets:
		if target not in setting_configs.keys():
			continue
		info = list2Dict(setting_configs[target])
		product_confuse_configs[target] = info
		confuse_type = get_dict_value(info, 'confuse-type', 'skip')
		confuse_c_symbol = get_dict_value(info, 'confuse-c-symbol',False)
		confuse_cpp_symbol = get_dict_value(info, 'confuse-cpp-symbol',False)
		confuse_objc_symbol = get_dict_value(info, 'confuse-objc-symbol',False)
		confuse_swift_symbol = get_dict_value(info, 'confuse-swift-symbol',False)
		if confuse_type == 'external':
			product_archive_files.append({'path' : get_product_build_file_path(work_dir, bundle_id, configure, workspace_profile, target), 'confuse-c-symbol' : confuse_c_symbol, 'confuse-cpp-symbol' : confuse_cpp_symbol, 'confuse-objc-symbol' : confuse_objc_symbol, 'confuse-swift-symbol' : confuse_swift_symbol})
	
def merge_product_archives_settings_file(archive_settings_file, file_name):
	settings = confuse_utils.read_settings_file(archive_settings_file)

	with open(file_name, 'w') as f:
		f.write('<archives>\n')

		archives = []
		if 'archives' in settings.keys():
			archives = settings['archives']
			for archive in archives:
				f.write('%s\n' % archive)
			
		i = 0
		for product_archive_file in product_archive_files:
			f.write('product_archive_%d\n' % i)
			i += 1
		i = 0

		for archive in archives:
			archive_file = list2Dict(settings[archive])
			f.write('<%s>\n' % archive)
			f.write('file = %s\n' % archive_file['file'])
			f.write('confuse-c-symbol = %s\n' % get_dict_value_str(archive_file, 'confuse-c-symbol', False))
			f.write('confuse-cpp-symbol = %s\n' % get_dict_value_str(archive_file, 'confuse-cpp-symbol', False))
			f.write('confuse-objc-symbol = %s\n' % get_dict_value_str(archive_file, 'confuse-objc-symbol', False))
			f.write('confuse-swift-symbol = %s\n' % get_dict_value_str(archive_file, 'confuse-swift-symbol', False))

		for product_archive_file in product_archive_files:
			f.write('<product_archive_%d>\n' % i)
			f.write('file = %s\n' % product_archive_file['path'])
			f.write('confuse-c-symbol = %s\n' % get_dict_value_str(product_archive_file, 'confuse-c-symbol', False))
			f.write('confuse-cpp-symbol = %s\n' % get_dict_value_str(product_archive_file, 'confuse-cpp-symbol', False))
			f.write('confuse-objc-symbol = %s\n' % get_dict_value_str(product_archive_file, 'confuse-objc-symbol', False))
			f.write('confuse-swift-symbol = %s\n' % get_dict_value_str(product_archive_file, 'confuse-swift-symbol', False))
			i += 1
		f.close()

def create_confuse_binary_script(xcworkspace_file, project_file, work_dir, bundle_id, main_bundle_id, target_name, archs, configure):
	print('##create confuse binary script.')

	global clang_version
	clang_version = confuse_utils.get_clang_version()

	global workspace_file
	workspace_file = xcworkspace_file
	workspace_dir = workspace_file[:workspace_file.rfind('/')]
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	pbxprojfile = '%s/project.pbxproj' % project_file
	project = XcodeProject.load(pbxprojfile)

	make_archive_xcconfig(package_dir, target_name, configure)

	depend_files = confuse_utils.read_settings_file(package_dir + '/depend_files.txt')

	global main_target_name
	main_target_name = target_name

	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target', False)
	script_file = '%s/confuse_%s_target_files.py' % (package_dir, target_name)
	f = open(script_file, 'w')
	#envs = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name, False)
	file_name = '%s/%s_environment_variables.txt' % (package_dir,target_name)
	envs = confuse_utils.read_properties_file(file_name)
	lines = []

	time_val = datetime.datetime.now().strftime('%Y-%m-%d@%H:%M:%S')
	with open('%s/template.py' % exe_dir, 'r') as tf:
		text = tf.read()
		text = text.replace('####CREATE_TIME####', time_val)
		text_lines = text.split('\n')
		for text_line in text_lines:
			lines.append(text_line)
		tf.close()

	cache_dir = '%s/cache/%s' % (work_dir, main_bundle_id)
	workspace_profile = load_workspace_profile(package_dir)
	project_name = confuse_utils.get_file_name(project_file)
	project_info = get_project_info_by_name(workspace_profile, project_name + '.xcodeproj')
	if project_info == None:
		print('not found %s.xcodeproj' % (project_name))
		sys.exit(1)

	load_product_confuse_configs(work_dir, bundle_id, configure, package_dir, workspace_profile)

	global ccache_enable
	global check_symbol_convert
	global check_link_file
	global check_link_symbol
	global check_target_file
	global check_code_file
	global dump_target_file_log
	global require_ui_kit
	global link_type
	global embed_swift
	global use_dyn_cosdk
	global cosdk_framework_dir
	global cosdk_name
	global exchange_object_file
	global replace_main
	global rename_confilict_source_file
	global require_swift_libraries

	ccache_enable = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'ccache', False)
	check_symbol_convert = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-symbol-convert', True)
	check_link_file = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-link-file', True)
	check_link_symbol = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-link-symbol', True)
	check_target_file = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-target-file', False)
	check_code_file = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-code-file', False)
	dump_target_file_log = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'dump-target-file-log', False)
	require_ui_kit = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'require-ui-kit', True)
	embed_swift = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'embed-swift', True)
	use_dyn_cosdk = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'use-dyn-cosdk', False)
	link_type = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'link-type', 'main-target')
	exchange_object_file = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'exchange-object-file', True)
	replace_main = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'replace-main', False)
	rename_confilict_source_file = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'rename-confilict-source-file', False)
	require_swift_libraries = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'require-swift-libraries', False)
	cosdk_name = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cosdk-name', 'COSDK')
	archive_settings_file = '%s/confuse_archive_configs.txt' % package_dir
	product_archive_settings_file = '%s/all_confuse_archive_configs.txt' % package_dir

	merge_product_archives_settings_file(archive_settings_file, product_archive_settings_file)
	depend_files = confuse_utils.read_settings_file(package_dir + '/depend_files.txt')

	cosdk_items = []
	if 'cosdk' in depend_files:
		cosdk_items = depend_files['cosdk']

	for item in cosdk_items:
		if item.endswith('%s.framework/%s' % (cosdk_name, cosdk_name)):
			item = item[:-22]
			cosdk_framework_dir = '%s/%s' % (workspace_dir, item.replace('{..}/', '../'))
	
	cmds = []
	create_script_text(cmds, envs, project, project_info, project_file, work_dir, exe_dir, bundle_id, package_dir, cache_dir, workspace_dir, product_archive_settings_file, target_name, archs.split('|'), configure, workspace_dir)
	gen_link_options_map_file(package_dir)

	group_defs = []
	python_defs = []
	for i in range(0, len(cmds)):
		cmd = cmds[i]
		if type(cmd) == list:
			gen_group_def(envs, cmd, i, group_defs, python_defs)
		else:
			if cmd.startswith('@python '):
				gen_python_def(envs, cmd, None, python_defs, None, i)
	
	for python_def in python_defs:
		lines.append(python_def)

	for group_def in group_defs:
		lines.append(group_def)

	lines.append('cmd_list = [')
	for i in range(0, len(cmds)):
		cmd = cmds[i]
		if type(cmd) == str:
			if cmd.startswith('@python '):
				lines.append('\tpython_script_%d, ' % (i))
			else:
				lines.append('\t"%s", ' % cmd_format(envs, cmd))
		else:
			lines.append('\tcmd_group_%d, ' % i)
	lines.append(']')
	lines.append('exec_cmd_list(cmd_list, True, load_exec_pos())')
	f.write('\n'.join(lines))
	f.close()
	pass

#
def main(argv):
	if len(argv) != 9:
		print('python create_confuse_binary_script.py [workspace file] [project file] [script dir] [work dir] [bundle id] [target name] [archs] [Debug/Release]')
		sys.exit(1)
	create_confuse_binary_script(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8])

main(sys.argv)
