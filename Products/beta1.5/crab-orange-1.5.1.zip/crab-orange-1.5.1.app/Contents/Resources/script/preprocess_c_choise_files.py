#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import json
import confuse_utils

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

def preprocess_project_code_file(workspace_dir, work_dir, bundle_id, main_bundle_id, project_file, project_name, task_id, configure, target_name, choise_files, depend_user_header_search_paths, project_header_map_file, target_header_map_file):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)

	if len(main_bundle_id):
		cache_dir = '%s/cache/%s' % (work_dir, main_bundle_id)
	else:
		cache_dir = '%s/cache' % package_dir
	source_cache_dir = '%s/cache' % (package_dir)
	os.system('mkdir -p \"%s\"' % cache_dir)
	
	listen_file = '%s/%s.listenkey' % (package_dir, bundle_id)
	warning_file = '%s/warning.txt' % package_dir
	all_code_file_path = '%s/all-code-files.txt' % package_dir
	code_file_path = '%s/%s.%s.choise.c.code-files' % (package_dir, project_name, target_name)

	confuse_utils.gen_choise_code_file('%s/%s.%s.c.code-files' % (package_dir, project_name, target_name), choise_files, code_file_path)

	excludes_file_path = '%s/exclude_object_configs.txt' % package_dir
	idmap_path = '%s/idmap.txt' % package_dir
	back_file_dir = '%s/back' % package_dir
	const_string_match_config_file = '%s/const_string_match_configs.txt' % package_dir
	exclude_config_file = '%s/exclude_object_configs.txt' % package_dir
	exclude_all_member_config_file = '%s/exclude_object_configs.txt.ext' % package_dir
	exclude_inflate_config_file = '%s/exclude_inflate_file_configs.txt' % package_dir

	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name, True, '-temp')
	prefixHeaderPath = confuse_utils.get_build_settings_value(build_settings, 'GCC_PREFIX_HEADER', '')
	framework_search_paths = confuse_utils.get_framework_search_paths_settings_value(build_settings)
	system_framework_search_paths = confuse_utils.get_system_framework_search_paths_settings_value(build_settings)

	head_search_paths = confuse_utils.get_header_search_paths_settings_value(build_settings)
	alwaysSearchUserPaths = confuse_utils.get_build_settings_value(build_settings, 'ALWAYS_SEARCH_USER_PATHS', 'YES')
	#user_head_search_paths = []
	#if alwaysSearchUserPaths == 'YES':
	user_head_search_paths = confuse_utils.get_user_header_search_paths_settings_value(build_settings)
	macros = confuse_utils.get_preprocess_settings_value(build_settings, ['OTHER_CFLAGS'])

	source_root = confuse_utils.get_build_settings_value(build_settings, 'SOURCE_ROOT', '')
	head_search_paths.append('%s' % package_dir)
	
	sdk_path = confuse_utils.get_build_settings_value(build_settings, 'SDKROOT', '')
	toolchain_dir = confuse_utils.get_build_settings_value(build_settings, 'TOOLCHAIN_DIR', '')
	clang_dir = confuse_utils.get_clang_dir(build_settings)
	lib_clang_include = confuse_utils.get_clang_resource_dir()

	c_language_standard = confuse_utils.get_build_settings_value(build_settings, 'GCC_C_LANGUAGE_STANDARD', None)
	#cxx_library = confuse_utils.get_build_settings_value(build_settings, 'CLANG_CXX_LIBRARY', None)

	#platform_arch = confuse_utils.get_build_settings_value(build_settings, 'PLATFORM_PREFERRED_ARCH', 'arm64')
	platform_arch = 'arm64'
	triple_os_version = confuse_utils.get_build_settings_value(build_settings, 'LLVM_TARGET_TRIPLE_OS_VERSION', '')
	if len(triple_os_version) == 0:
		values = confuse_utils.get_build_settings_value(build_settings, 'DEPLOYMENT_TARGET_SUGGESTED_VALUES', [])
		if len(values):
			triple_os_version = 'ios' + values[0]
		else:
			triple_os_version = 'ios6.0'

	args = "-bundle-id=%s" % (bundle_id)
	args = "%s\n-listen-file=%s" % (args, listen_file)
	args = "%s\n-target-name=%s" % (args, target_name)
	args = "%s\n-task-id=%s" % (args, task_id)
	args = "%s\n-warning-file=%s" % (args, warning_file)
	args = "%s\n-source-file=%s" % (args, code_file_path)
	args = "%s\n-cache-dir=%s" % (args, cache_dir)
	args = "%s\n-source-cache-dir=%s" % (args, source_cache_dir)
	args = "%s\n-const-string-match-config-file=%s" % (args, const_string_match_config_file)
	args = "%s\n-exclude-config-file=%s" % (args, exclude_config_file)
	args = "%s\n-exclude-all-member-config-file=%s" % (args, exclude_all_member_config_file)
	args = "%s\n-exclude-inflate-config-file=%s" % (args, exclude_inflate_config_file)
	args = "%s\n-configure=%s" % (args, configure)
	args = "%s\n-clear-unhit=%s" % (args, 'source')
	args = "%s\n-check-error=%s" % (args, 'true')
	args = "%s\n-worker-count=%d" % (args, confuse_utils.get_worker_count(work_dir, bundle_id))
	need_check_error = False
	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-code-error', True):
		args = "%s\n-check-error=%s" % (args, 'true')
		need_check_error = True
	cosdk_name = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cosdk-name', 'COSDK')
	args = "%s\n-cosdk-name=%s" % (args, cosdk_name)
	#args = "%s\n-force=true" % (args)
	#args = "%s\n-cxx-include=%s/usr/include/c++/v1" % (args, toolchain_dir)
	args = "%s\n%s" % (args, project_file)
	args = "%s\n--" % args
	args = "%s\n-Wno-error" % (args)
	
	if c_language_standard != None:
		args = "%s\n-std=%s" % (args, confuse_utils.get_std_value(c_language_standard))
	args = "%s\n-fmodules" % (args)

	if len(prefixHeaderPath):
		if prefixHeaderPath.startswith('/'):
			args = "%s\n-include%s" % (args, prefixHeaderPath)
		else:
			args = "%s\n-include%s/%s" % (args, source_root, prefixHeaderPath)
	#args = "%s\n-include%s/default.h" % (args, exe_dir)
			
	args = "%s\n-mios-version-min=9.0" % args
	args = "%s\n-isysroot%s" % (args, sdk_path)
	args = "%s\n-resource-dir=%s" % (args, lib_clang_include)
	oldcat_sdk_path = confuse_utils.get_oldcat_sdk_path(work_dir, bundle_id)
	if oldcat_sdk_path != None:
		args = "%s\n-iquote%s/%s" % (args, workspace_dir, oldcat_sdk_path)
	args = "%s\n-F%s/System/Library/Frameworks" % (args, sdk_path)
	#args = "%s\n-ferror-limit=9999999" % args

	args = "%s\n-idirafter%s" % (args, project_header_map_file)
	args = "%s\n-iquote%s" % (args, project_header_map_file)
	args = "%s\n-I%s" % (args, target_header_map_file)

	for framework_search_path in system_framework_search_paths:
		if len(framework_search_path):
			args = "%s\n-iframework%s" % (args, framework_search_path)

	for framework_search_path in framework_search_paths:
		if len(framework_search_path) > 0:
			args = "%s\n-F%s" % (args, framework_search_path)

	for head_search_path in head_search_paths:
		if len(head_search_path) > 0:
			args = "%s\n-I%s" % (args, head_search_path)

	for user_head_search_path in user_head_search_paths:
		if len(user_head_search_path) > 0:
			if alwaysSearchUserPaths == 'YES':
				args = "%s\n-I%s" % (args, user_head_search_path)
			else:
				args = "%s\n-iquote%s" % (args, user_head_search_path)

	for user_head_search_path in depend_user_header_search_paths:
		if len(user_head_search_path) > 0:
			args = "%s\n-I%s" % (args, user_head_search_path)

	for macro in macros:
		if len(macro) > 0:
			args = "%s\n-D%s" % (args, macro)

	cmdfile = '%s/%s-%s.choise.c.cmd.txt' % (package_dir, project_name, target_name)
	with open(cmdfile, 'w') as f:
		f.write(args)
		f.close()

	derived_data_dir = confuse_utils.get_xcode_derived_data_dir()
	cmd = '%s/%s/clang-tools "code-preprocess" "%s" "%s" "%s" "%s" "%s" "c"' % (exe_dir, clang_dir, work_dir, cmdfile, derived_data_dir, platform_arch, triple_os_version)
	ret = confuse_utils.exec_cmd(cmd)
	#sys.exit(1)
	if ret != 0 and need_check_error:
		sys.exit(1)
	pass

def find_target(projects, dependencie):
	target_name = dependencie['target']
	project_name = dependencie['project']
	for project in projects:
		if project['name'] != project_name:
			continue
		for target in project['targets']:
			if target['name'] == target_name:
				return target, project
	return None, None

def get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, project, target, history):
	project_file = project['path']
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target['name'], True)
	alwaysSearchUserPaths = confuse_utils.get_build_settings_value(build_settings, 'ALWAYS_SEARCH_USER_PATHS', 'YES')
	ret = []
	if alwaysSearchUserPaths == 'YES':
		ret = confuse_utils.get_user_header_search_paths_settings_value(build_settings)
	dependencies = target['dependencies']
	for dependencie in dependencies:
		findtarget,findproject = find_target(projects, dependencie)
		if findtarget == None or findtarget['name'] in history:
			continue
		paths = get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, findproject, findtarget, history)
		for path in paths:
			if path not in ret:
				ret.append(path)
		history.append(findtarget['name'])
	return ret

def preprocess_c_files(work_dir, bundle_id, main_bundle_id, workspace_info_file, project_name, target_name, task_id, configure, choise_files):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	
	print('preprocess workspace %s c choise files' % workspace_info_file)
	found_project = False
	with open(workspace_info_file, 'r') as load_f:
		js = json.load(load_f)
		workspace_dir = confuse_utils.get_file_dir(js['workspace-file'])
		projects = js['projects']
		for project in projects:
			project_file = project['path']
			name = project['name']

			if name != project_name:
				continue

			found_project = True
			targets = project['targets']
			if len(targets) == 0:
				confuse_utils.trace_error('not found targets in project \"%s\"' % name)
			project_header_map_file = project['project-header-map-file']
			public_header_map_file = project['public-header-map-file']
			targets = project['targets']
			for target in targets:
				target_name = target['name']
				if target_name != target['name']:
					continue
				print('target:%s' % target_name)
				depend_user_header_search_paths = get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, project, target, [])
				preprocess_project_code_file(workspace_dir, work_dir, bundle_id, main_bundle_id, project_file, confuse_utils.get_file_name(project_name), task_id, configure, target_name, choise_files, depend_user_header_search_paths, project_header_map_file, public_header_map_file)

	if found_project == False:
		confuse_utils.trace_error('not found project \"%s\" in %s' % (project_name, workspace_info_file))
	print('preprocess workspace %s finish' % workspace_info_file)
	pass

# cd /Users/crab/Documents/myprojects/clang-confuse/resource/projectmanager/other/script
# python preprocess_objc_files.py ~/Library/projectmanager com.my.SampleCode ~/Library/projectmanager/packages/com.my.SampleCode/workspace_info.json SampleCode.xcodeproj temp32

def main(argv):
	if len(argv) < 10:
		print('python preprocess_choise_c_files.py [work dir] [bundle id] [main bundle id] [workspace info file] [project name] [target name] [task id] [Debug/Release] [choise file ...]')
		sys.exit(1)
	choise_files = []
	for i in range(9, len(argv)):
		choise_files.append(argv[i])
	preprocess_c_files(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], choise_files)
	
main(sys.argv)