#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import struct
import importlib

importlib.reload(sys)
#sys.setdefaultencoding('utf8')

def confuse_file(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
    print('##confuse resource %s##' % src_file)
    confuse_utils.dbfile_lock()
    src_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
    confuse_utils.dbfile_unlock()
    package_dir = '%s/packages/%s' % (work_dir, bundle_id)
    if not os.path.exists(src_file):
        print('warning:not found %s' % src_file)
        return
    try:
        seed_key = confuse_utils.get_seed_key(package_dir)
        src_file_back = src_file + '.back'
        if os.path.exists(src_file_back):
            os.remove(src_file_back)
        confuse_utils.copy_file(src_file, src_file_back)
        os.remove(src_file)
        rand_key = ((seed_key >> 24) & 0xff, (seed_key >> 16) & 0xff, (seed_key >> 8) & 0xff, seed_key & 0xff)

        with open(src_file_back, 'rb') as f1:
            data = bytearray(f1.read())
            max_len = len(data)
            i = 0
            while i < max_len:
                for j in range(0, len(rand_key)):
                    pos = i + j
                    if pos >= max_len:
                        break
                    data[pos] = rand_key[j] ^ data[i + j]
                i = i + len(rand_key)

            temp_data = confuse_utils.get_inflate_data()
            with open(src_file, 'wb') as f2:
                f2.write(data)
                f2.write(temp_data)
                f2.write(struct.pack('I', len(temp_data)))
                f2.write(struct.pack('II', seed_key, seed_key + 1))
                f2.close()
            f1.close()
        os.remove(src_file_back)
    except IOError:
        os.rename(src_file_back, src_file)
        print('warning:ios error in %s' % (src_file))
    pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python confuse_file.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		return
	confuse_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)