#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import getpass
import json
import confuse_utils

abs_file_path = os.path.abspath(__file__)
script_dir = abs_file_path[0:abs_file_path.rfind('/')]

def get_clang_version(resource_dir):
	idx = resource_dir.rfind('/clang/')
	version = resource_dir[idx + 7:]
	return version

def gen_source_file(headers_dir, source_file_name, framework_name):
	framework_path_name = headers_dir[headers_dir.rfind('/') + 1:]
	items = []
	for root, dirs, files in os.walk(headers_dir):
		for file in files:
			if file.endswith('.h') == False:
				continue
			path = os.path.join(root, file)
			start = path.rfind(framework_path_name)
			dirname = framework_name[:framework_name.rfind('.framework')]
			relpath = path[start + len(framework_path_name) + 1:]
			
			if relpath == dirname + '.h':
				items.insert(0, relpath)
			else:
				items.append(relpath)
	with open(source_file_name, 'w') as f:
		for item in items:
			f.write('#import <%s/%s>' % (dirname, item))
			f.write('\n')
		f.close()
		
def gen_headers_file(headers_dir, source_file_name, tbd_file, apinotes_file):
	with open(source_file_name, 'w') as f:
		f.write(tbd_file)
		f.write('\n')
		f.write(apinotes_file)
		f.write('\n')
		for root, dirs, files in os.walk(headers_dir):
			for file in files:
				if file.endswith('.h') == False:
					continue
				path = os.path.join(root, file)
				f.write(path)
				f.write('\n')
		f.close()

def list_frameworks(dirpath):
	paths = []
	names = []
	items = os.listdir(dirpath)
	for item in items:
		if item.endswith('.framework'):
			paths.append('%s/%s' % (dirpath, item))
			names.append(item)
	return paths, names

def gen_subframeworks_file(filename, subdirs):
	with open(filename, 'w') as f:
		for subdir in subdirs:
			f.write('%s\n' % subdir)
		f.close()

def symbol_collector(work_dir, bundle_id, framework_dir, parent_framworks_dir, cache_dir_name, framework_name, configure, sdk_root, tbd_file, apinotes_file):
	frameworks_dir = '%s/Frameworks' % framework_dir
	#print(framework_dir)
	if os.path.exists(frameworks_dir):
		framework_dirs, framework_names = list_frameworks(frameworks_dir)
		for i in range(0, len(framework_names)):
			dirpath = framework_dirs[i]
			dirname = framework_names[i]
			symbol_collector(work_dir, bundle_id, dirpath, frameworks_dir, '%s/%s' % (cache_dir_name, dirname), dirname, configure, sdk_root, tbd_file, apinotes_file)
		subframeworks = cache_dir_name + '/subframeworks.txt'
		gen_subframeworks_file(subframeworks, framework_names)

	headers_dir = '%s/Headers' % framework_dir

	if os.path.exists(cache_dir_name) == False:
		os.system('mkdir -p %s' % cache_dir_name)

	tmpdir = '/var/tmp'
	source_file_name = tmpdir + '/%s.mm' % framework_name
	headers_file_name = cache_dir_name + '/headers.txt'
	link_frameworks_list_file = cache_dir_name + '/link_frameworks.txt'
	gen_source_file(headers_dir, source_file_name, framework_name)
	gen_headers_file(headers_dir, headers_file_name, tbd_file, apinotes_file)

	sdk_path = confuse_utils.get_xcode_sdk_path()
	toolchain_dir = confuse_utils.get_toolchain_dir(sdk_path)
	lib_clang_include = confuse_utils.get_clang_resource_dir()
	derived_data_dir = confuse_utils.get_xcode_derived_data_dir()
	clang_dir = confuse_utils.get_clang_dir(None)

	args = '-task-type=symbol-collector'
	args = '%s\n-configure=%s' % (args, configure)
	args = '%s\n-header-file=%s' % (args, headers_file_name)
	args = '%s\n-source-file=%s' % (args, source_file_name)
	args = '%s\n-cache-dir=%s' % (args, cache_dir_name)
	args = "%s\n-framework-name=%s" % (args, confuse_utils.get_file_name(framework_name))
	args = "%s\n-link-frameworks-file=%s" % (args, link_frameworks_list_file)
	args = "%s\n-sdk-root=%s" % (args, sdk_root)
	args = "%s\n-tbd-file=%s" % (args, tbd_file)
	args = "%s\n-apinotes-file=%s" % (args, apinotes_file)
	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'ccache', False):
		args = "%s\n-ccache-enable=true" %  args
	args = "%s\n%s" % (args, cache_dir_name)
	args = "%s\n--" % args
	args = '%s\n-w' % args
	#args = "%s\n-mios-version-min=6.0" % args
	args = "%s\n-isysroot%s" % (args, sdk_path)
	args = "%s\n-resource-dir=%s" % (args, lib_clang_include)
	args = "%s\n-F%s/System/Library/Frameworks" % (args, sdk_path)
	#clang_version = get_clang_version(lib_clang_include)
	#if clang_version < '12.0':
	#	args = "%s\n-isystem%s/usr/include/c++/v1" % (args, toolchain_dir)
	args = "%s\n-ferror-limit=9999999" % args
	args = "%s\n-stdlib=libc++" % args
	args = "%s\n-std=gnu++14" % args
	#args = "%s\n-fobjc-weak" % args
	#args = "%s\n-fobjc-arc" % args
	args = "%s\n-Werror=non-modular-include-in-framework-module" % (args)
	args = "%s\n-Wmodule-import-in-extern-c" % (args)

	if os.path.exists(frameworks_dir):
		args = "%s\n-F%s\"" % (args, confuse_utils.pstr(frameworks_dir))

	if parent_framworks_dir != None:
		args = "%s\n-F%s" % (args, confuse_utils.pstr(parent_framworks_dir))
	
	cmdfile = '%s/%s.cmd.txt' % (tmpdir, framework_name)
	with open(cmdfile, 'w') as f:
		f.write(args)
		f.close()
	cmd = "%s/%s/clang-tools 'symbol-collector' '%s' '%s' '%s' arm64 ios6.0 objc++" % (script_dir, clang_dir, work_dir, cmdfile, derived_data_dir)
	print(cmd)
	ret = os.system(cmd)
	if ret != 0:
		sys.exit(1)

def main(argv):
	if len(argv) != 10:
		print('python symbol_collector.py [work dir] [bundle id] [framework dir] [cache dir name] [framework_name] [configure] [sdk root] [tbd file] [apinotes file]')
		sys.exit(1)

	work_dir = argv[1]
	bundle_id = argv[2]
	framework_dir = argv[3]
	cache_dir_name = argv[4]
	framework_name = argv[5]
	configure = argv[6]
	sdk_root = argv[7]
	tbd_file = argv[8]
	apinotes_file = argv[9]
	symbol_collector(work_dir, bundle_id, framework_dir, None, cache_dir_name, framework_name, configure, sdk_root, tbd_file, apinotes_file)
	pass

main(sys.argv)