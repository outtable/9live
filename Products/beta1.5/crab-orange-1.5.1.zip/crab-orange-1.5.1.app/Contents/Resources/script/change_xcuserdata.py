#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import biplist
import confuse_utils

def change_xcuserdata(workspace_dir, work_dir, bundle_id, target_name):
	#IDENameString
	#new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	new_target_name = '%s(%s)' % (target_name, bundle_id)
	xcuserdata_dir = workspace_dir + '/xcuserdata'
	if os.path.exists(xcuserdata_dir) == False:
		return
	dirs = os.listdir(xcuserdata_dir)
	for name in dirs:
		file_name = xcuserdata_dir + '/' + name + '/UserInterfaceState.xcuserstate'
		if os.path.exists(file_name):
			try:
				dict = biplist.readPlist(file_name)
				objects = dict['$objects']
				for i in range(0, len(objects)):
					obj = objects[i]
					if isinstance(obj, str):
						if obj == 'IDENameString':
							if objects[i + 1] == target_name:
								objects[i + 1] = new_target_name
								print('change xcuserdata target to %s' % new_target_name)
				biplist.writePlist(dict, file_name)
			except:
				print('warning:change xcuserdata target error.')
				pass
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 5:
		print('python change_xcuserdata.py [workspace dir] [work dir] [bundle id] [target name]')
		return
	change_xcuserdata(argv[1], argv[2], argv[3], argv[4])

main(sys.argv)