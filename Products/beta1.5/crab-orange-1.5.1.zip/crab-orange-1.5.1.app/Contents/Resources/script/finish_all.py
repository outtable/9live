#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os

def finish_all(work_dir, bundle_id, title, messsage):
	print('##finish all##')
	os.system("osascript -e 'display notification \"%s\" with title \"%s\"'" % (messsage, title))
	pass

def main(argv):
	if len(argv) != 5:
		print('python finish_all.py [work dir] [bundle id] [title] [message]')
		return
	finish_all(argv[1], argv[2], argv[3], argv[4])

main(sys.argv)