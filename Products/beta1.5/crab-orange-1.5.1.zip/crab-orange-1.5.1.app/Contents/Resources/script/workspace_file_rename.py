#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import shutil

def workspace_file_rename(work_dir, bundle_id):
	print('##workspace files rename##')
	confuse_utils.begin_transaction(work_dir, bundle_id)
	renames = confuse_utils.get_all_file_rename(work_dir, bundle_id, False)

	for file_rename in renames:
		filename = file_rename[0]
		newname = file_rename[1]
		if not os.path.exists(filename) and os.path.exists(newname):
			continue
		print('rename %s to %s' % (filename, newname))
		confuse_utils.rename_file(filename, newname)
		confuse_utils.add_temp_file(work_dir, bundle_id, newname, False)
	confuse_utils.commit_transaction()
	pass
	
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 3:
		print('python preprocess_objc_files.py [work dir] [bundle id]')
		sys.exit(1)
	workspace_file_rename(argv[1], argv[2])
	
main(sys.argv)