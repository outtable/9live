#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import importlib
importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

import os
import shutil
from pbxproj import XcodeProject
import confuse_utils

def get_abs_path(relpath, file_info, build_settings):
	path = file_info['path']
	name = file_info['name']

	if path == None:
		return os.path.abspath(relpath);

	if file_info.sourceTree =='<group>':
		abspath = relpath + '/' + path
	elif file_info.sourceTree in build_settings:
		abspath = build_settings[file_info.sourceTree] + '/' + path
	else:
		abspath = path
	return os.path.abspath(abspath)

def load_inner_xcproject(project, relpath, group, result, build_settings):
	group_path = get_abs_path(relpath, group, build_settings)
	for child_id in group.children:
		child = project.get_object(child_id)

		if isinstance(child, project._get_class_reference('PBXGroup')):
			load_inner_xcproject(project, group_path, child, result, build_settings)
			pass
		elif isinstance(child, project._get_class_reference('PBXFileReference')):
			child_path = child['path']
			filepath = get_abs_path(group_path, child, build_settings)
			if os.path.exists(filepath):
				if filepath.endswith('.xcodeproj'):
					result.append(filepath)
			pass
	pass
	
def create_xcworkspace(project_file):
	build_settings = confuse_utils.get_project_build_settings(project_file)
	filename = confuse_utils.get_file_name(project_file)
	filedir = confuse_utils.get_file_dir(project_file)
	pbxprojfile = '%s/project.pbxproj' % project_file

	project = XcodeProject.load(pbxprojfile)
	rootObject = project.get_object(project.rootObject)
	mainGroupId = rootObject.mainGroup
	mainGroup = project.get_object(mainGroupId)

	result = []
	load_inner_xcproject(project, project._source_root, mainGroup, result, build_settings)
	workspace_file = '%s/%s.xcworkspace' % (filedir, filename)
	if os.path.exists(workspace_file):
		shutil.rmtree(workspace_file)
	os.makedirs(workspace_file)
	with open('%s/contents.xcworkspacedata' % workspace_file, 'w') as f:
		f.write('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n')
		f.write('<Workspace version =\"1.0\">\n')
		f.write('<FileRef location = \"group:%s.xcodeproj"></FileRef>\n' % filename)
		for item in result:
			rel_file = os.path.relpath(item, project._source_root)
			f.write('<FileRef location =\"group:%s\"></FileRef>\n' % rel_file)
		f.write('</Workspace>')
		f.close()
	pass

def main(argv):
	if len(argv) != 2:
		print('python create_xcworkspace.py [project file]')
		return
		
	create_xcworkspace(argv[1])
	
main(sys.argv)