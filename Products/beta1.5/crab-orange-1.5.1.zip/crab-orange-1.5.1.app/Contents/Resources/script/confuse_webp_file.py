#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import image_utils
import random

from PIL import ImageEnhance
from PIL import Image

def confuse_webp(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('##confuse webp file %s##' % src_file)
	confuse_utils.dbfile_lock()
	src_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	confuse_utils.dbfile_unlock()
	if not os.path.exists(src_file):
		print('warning:not found %s' % src_file)
		return
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	try:
		src_file_back = src_file + '.back'
		if os.path.exists(src_file_back):
			if os.path.exists(src_file):
				os.remove(src_file)
			os.rename(src_file_back, src_file)
		os.link(src_file, src_file_back)
		src_img = Image.open(src_file)
		image_utils.encode_key_to_image(src_img, bundle_id)
		os.remove(src_file)
		src_img.save(src_file)
		image_utils.inflate_file(src_file)
		os.remove(src_file_back)
	except:
		os.rename(src_file_back, src_file)
		print('warning:ios error in %s' % (src_file))
		
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python confuse_webp.py [work dir] [bundle id] [target name] [product type] [product file] [install dir] [product target name] [src file] [ref folder]')
		return
	confuse_webp(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)