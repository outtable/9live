#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os

def remove_file(src_file):
	if src_file == '/':
		print('remove %s error' % src_file)
		sys.exit(1)
	os.system('rm -rf \"%s\"' % src_file)
	pass

def main(argv):
	if len(argv) != 2:
		print('python remove_file.py [src file]')
		return
	remove_file(argv[1])

main(sys.argv)