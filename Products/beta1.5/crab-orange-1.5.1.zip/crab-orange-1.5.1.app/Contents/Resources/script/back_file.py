#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def is_filter_file(file_name):
	suffixs = [".xcodeproj", ".xcworkspace"]
	if os.path.isdir(file_name):
		for suffix in suffixs:
			if file_name.endswith(suffix):
				return True
	return False

def copy_file(work_dir, bundle_id, src_file, dst_file):
	print('##backup file %s to %s##' % (src_file, dst_file))
	if is_filter_file(src_file):
		confuse_utils.copy_file(src_file, dst_file)
		confuse_utils.dbfile_lock()
		confuse_utils.add_backup_file(work_dir, bundle_id, src_file, dst_file)
		confuse_utils.dbfile_unlock()
	else:
		confuse_utils.fast_copy_file(src_file, dst_file)
		confuse_utils.dbfile_lock()
		confuse_utils.add_backup_file(work_dir, bundle_id, src_file, dst_file)
		confuse_utils.dbfile_unlock()
	pass

def back_file(workspace_file, src_file, work_dir, bundle_id):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	back_dir = '%s/back' % package_dir
	if os.path.exists(back_dir) == False:
		os.system('mkdir -p \"%s\"' % back_dir)
	relpath = confuse_utils.get_rel_path(workspace_file, src_file)
	relpath = relpath.replace('../', '{..}/')
	dst_file = '%s/back/%s' % (package_dir, relpath)
	copy_file(work_dir, bundle_id, src_file, dst_file)
	pass

def main(argv):
	if len(argv) != 5:
		print('python back_file.py [*.xcworkspace] [src file] [work dir] [bundle id]')
		return
	
	back_file(argv[1], argv[2], argv[3], argv[4])

main(sys.argv)