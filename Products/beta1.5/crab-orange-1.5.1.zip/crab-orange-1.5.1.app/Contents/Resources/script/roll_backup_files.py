#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def roll_backup_file(work_dir, bundle_id):
	print('##roll backup files %s ##' % bundle_id)
	confuse_utils.roll_backup_files(work_dir, bundle_id)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 3:
		print('python roll_backup_file.py [work dir] [bundle id]')
		return
	roll_backup_file(argv[1], argv[2])

main(sys.argv)