#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import json
import confuse_utils

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

def get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	if target_name == None and project_name == None:
		target_dir = '%s/SwiftBridgeHeaders' % (package_dir)
	else:
		target_dir = '%s/SwiftBridgeHeaders/%s/%s' % (package_dir, confuse_utils.md5str(project_name), target_name)
	return target_dir

def preprocess_project_code_file(workspace_dir, work_dir, bundle_id, main_bundle_id, project_file, project_name, task_id, configure, target_name, bardgate_code_rate, is_first_task, is_last_task):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)

	if len(main_bundle_id):
		cache_dir = '%s/cache/%s' % (work_dir, main_bundle_id)
	else:
		cache_dir = '%s/cache' % package_dir
	source_cache_dir = '%s/cache/%s' % (package_dir, target_name)
	os.system('mkdir -p \"%s\"' % cache_dir)
	os.system('mkdir -p \"%s\"' % source_cache_dir)
	
	listen_file = '%s/%s.listenkey' % (package_dir, bundle_id)
	#warning_file = '%s/warning.txt' % package_dir
	#all_code_file_path = '%s/all-code-files.txt' % package_dir
	code_file_path = '%s/%s.%s.swift.code-files' % (package_dir, project_name, target_name)
	excludes_file_path = '%s/exclude_object_configs.txt' % package_dir
	#const_string_match_config_file = '%s/const_string_match_configs.txt' % package_dir
	#exclude_config_file = '%s/exclude_object_configs.txt' % package_dir
	#exclude_all_member_config_file = '%s/exclude_object_configs.txt.ext' % package_dir
	exclude_inflate_config_file = '%s/exclude_inflate_file_configs.txt' % package_dir
	
	cstring_encode = 'false'

	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'swift-string-encode', True):
		cstring_encode = 'true'
	
	dbfile = '%s/symbols.db' % work_dir
	args = "--bundle-id=%s" % (bundle_id)
	args = "%s --target-name=\"%s\"" % (args, confuse_utils.pstr(target_name))
	args = "%s --listen-file=%s" % (args, listen_file)
	args = "%s --source-file=\"%s\"" % (args, confuse_utils.pstr(code_file_path))
	args = "%s --dbfile=%s" % (args, dbfile)
	args = "%s --source-cache-dir=\"%s\"" % (args, confuse_utils.pstr(source_cache_dir))
	args = "%s --exclude-inflate-config-file=%s" % (args, exclude_inflate_config_file)
	args = "%s --configure=%s" % (args, configure)
	if configure == 'Release':
		args = "%s --bardgate-code-rate=%s" % (args, bardgate_code_rate)
	else:
		args = "%s --bardgate-code-rate=0" % (args)
	args = "%s --confuse-string=%s" % (args, cstring_encode)
	need_check_error = False
	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'check-code-error', True):
		need_check_error = True
	#if need_check_error:
	#	args = "%s --check-error=%s" % (args, 'true')
	#else:
	#	args = "%s --check-error=%s" % (args, 'false')
	derived_data_dir = confuse_utils.get_xcode_derived_data_dir()
	cmd = '%s/swift-tools %s' % (exe_dir, args)
	ret = confuse_utils.exec_cmd(cmd)
	#sys.exit(1)
	if ret != 0 and need_check_error:
		sys.exit(1)
	pass

def preprocess_swift_files(work_dir, bundle_id, main_bundle_id, workspace_info_file, project_name, task_id, configure, bardgate_code_rate, is_first_task, is_last_task):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	print('preprocess workspace %s swift files' % workspace_info_file)
	found_project = False
	with open(workspace_info_file, 'r') as load_f:
		js = json.load(load_f)
		workspace_dir = confuse_utils.get_file_dir(js['workspace-file'])
		projects = js['projects']
		for project in projects:
			project_file = project['path']
			name = project['name']

			if name != project_name:
				continue

			found_project = True
			targets = project['targets']
			if len(targets) == 0:
				confuse_utils.trace_error('not found targets in project \"%s\"' % name)
			for target in targets:
				target_name = target['name']
				print('target:%s' % target_name)
				preprocess_project_code_file(workspace_dir, work_dir, bundle_id, main_bundle_id, project_file, confuse_utils.get_file_name(project_name), task_id, configure, target_name, bardgate_code_rate, is_first_task, is_last_task)

	if found_project == False:
		confuse_utils.trace_error('not found project \"%s\" in %s' % (project_name, workspace_info_file))
	print('preprocess workspace %s finish' % workspace_info_file)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 11:
		print('python preprocess_swift_files.py [work dir] [bundle id] [main bundle id] [workspace info file] [project name] [task id] [Debug/Release] [bardgate code rate] [is first task] [is last task]')
		sys.exit(1)
	preprocess_swift_files(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10])
	
main(sys.argv)