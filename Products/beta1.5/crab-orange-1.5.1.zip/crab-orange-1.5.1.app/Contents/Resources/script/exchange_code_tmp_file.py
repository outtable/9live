#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os

def exchange_code_tmp_file(src_file):
	if os.path.exists(src_file + '.tmp'):
		print('##exchange confound code file %s##' % src_file)
		os.remove(src_file)
		os.rename(src_file + '.tmp', src_file)
	else:
		print('%s.tmp is not exists.' % src_file)
	pass

def main(argv):
	if len(argv) != 2:
		print('python exchange_code_tmp_file.py [src file]')
		sys.exit(1)
	exchange_code_tmp_file(argv[1])

main(sys.argv)