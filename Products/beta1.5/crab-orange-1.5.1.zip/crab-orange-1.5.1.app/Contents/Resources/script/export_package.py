#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import zipfile

filenames = [
	'compile_configs.txt',
	'const_string_match_configs.txt',
	'default_script.txt',
	'depend_files.txt',
	'exclude_confuse_file_configs.txt',
	'exclude_object_configs.txt',
	'exclude_rename_file_configs.txt',
	'exclude_inflate_file_configs.txt',
	'ccache_configs.txt',
	'file_group_configs.txt',
	'runsettings.cfg.txt',
	'confuse_archive_configs.txt',
	'confuse_product_archive_configs.txt',
	'depends',
]

def export_package(work_dir, bundle_id, file_name):
	print('##export package ##')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	f  = zipfile.ZipFile(file_name, 'w', zipfile.ZIP_STORED)
	for filename in filenames:
		filepath = '%s/%s' % (package_dir, filename)
		if os.path.isdir(filepath):
			for root,dirs,files in os.walk(filepath):
				for file in files:
					fullpath = os.path.join(root,file)
					f.write(fullpath, fullpath[len(package_dir):])
		else:
			f.write(filepath, filepath[len(package_dir):])
	f.close()
	pass

#python export_package.py /Users/carb/Library/ipa-artifact com.zuimeiqidai.ios.test.objc ~/Desktop/fuck.zip
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 4:
		print('python export_package.py [work dir] [bundle id] [zip file name]')
		return
	export_package(argv[1], argv[2], argv[3])

main(sys.argv)