#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import json
import importlib

importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

def scan_sdk_root(platform_name):
	sdk_version = None
	sdk_path = None
	json_ret = {}
	b = os.popen('xcodebuild -showsdks -json')
	jstxt = ''.join(b.readlines())
	jsobj = json.loads(jstxt)
	for info in jsobj:
		platform = info['platform']
		if platform == platform_name:
			sdk_version = info['sdkVersion']
			sdk_path = info['sdkPath']
			break
	if sdk_path != None:
		json_ret['version'] = sdk_version
		files = os.listdir('%s/usr/lib' % sdk_path)
		liblist = []
		swift_liblist = []
		json_ret['libraries'] = liblist
		json_ret['swift-libraries'] = swift_liblist
		for file in files:
			if file == 'swift':
				childfiles = os.listdir('%s/usr/lib/swift' % (sdk_path))
				for childfile in childfiles:
					if childfile.endswith('.tbd'):
						swift_liblist.append(childfile)
			else:
				liblist.append(file)
		files = os.listdir('%s/System/Library/Frameworks' % sdk_path)
		frameworklist = []
		json_ret['frameworks'] = frameworklist
		for file in files:
			if file.startswith('_'):
				continue
			frameworklist.append(file)

	print(json.dumps(json_ret))
	pass

def main(argv):
	if len(argv) != 2:
		print('python scan_sdk_root.py [platform]')
		sys.exit(1)
	
	scan_sdk_root(argv[1])

main(sys.argv)