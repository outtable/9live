#!/usr/bin/python
# -*- coding: utf-8 -*-  

import ctypes
import sys
import os
import importlib

importlib.reload(sys)
#sys.setdefaultencoding('utf8')

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/Contents')]
mydylib = ctypes.cdll.LoadLibrary('%s/Contents/Frameworks/libpysemlock.dylib' % exe_dir)

def PySemLock_create(keyId):
	return mydylib.PySemLock_create(keyId.encode('utf-8'))

def PySemLock_get(keyId):
	return mydylib.PySemLock_lookup(keyId.encode('utf-8'))

def PySemLock_lock(semLock):
	mydylib.PySemLock_lock(semLock)
	pass

def PySemLock_unlock(semLock):
	mydylib.PySemLock_unlock(semLock)
	pass

def PySemLock_destory(semLock):
	mydylib.PySemLock_free(semLock)
	pass