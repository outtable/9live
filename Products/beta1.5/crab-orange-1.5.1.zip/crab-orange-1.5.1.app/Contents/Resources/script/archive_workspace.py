#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import datetime

def archive_workspace(workspace, work_dir, bundle_id, target_name, archs, configure):
	print('##archive workspace %s %s##' % (bundle_id, configure))
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')

	cmds = []
	#install mobileprovision
	mobile_provision_info,has_config,identify = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, bundle_id, target_name)
	mobile_provision_file = mobile_provision_info['FILE_NAME']
	mobile_provision_uuid = mobile_provision_info['UUID']
	team_id = mobile_provision_info['TEAM_ID']

	if len(team_id) == 0:
		print('mobile provision file is error.')
		sys.exit(1)
	
	ppdir = '%s/Library/MobileDevice/Provisioning Profiles' % (os.path.expanduser('~'))
	if not os.path.exists(ppdir):
		cmd = 'mkdir -p \"%s\"' % ppdir
		cmds.append(cmd)
		pass

	to_mobile_provision_file = '%s/%s.mobileprovision' % (ppdir, mobile_provision_uuid)
	if mobile_provision_file != to_mobile_provision_file:
		cmd = 'cp -f \"%s\" \"%s\"' % (mobile_provision_file, to_mobile_provision_file)
		cmds.append(cmd)

	#archive workspace
	workspace_dir = confuse_utils.get_file_dir(workspace)

	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	cmds.append('cd \"%s\"' % (workspace_dir))
	
	cmds.append('rm -rf \"%s\"' % archive_path)
	
	cmd = 'xcodebuild clean -workspace \"%s\" -scheme \"%s\" -configuration \"%s\"' % (workspace, target_name, configure)
	cmds.append(cmd)

	arch_arr = archs.split('|')
	archs_str = ''
	for arch in arch_arr:
		archs_str = '%s -arch %s' % (archs_str, arch)

	build_no_sign = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'build-no-sign', False)
	build_log_out = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'build-log-out', 0)
	sign_config = ''
	current_date = datetime.datetime.now()
	formatted_date = current_date.strftime('%Y-%m-%d')
	log_dir = '%s.%s' % (target_name, formatted_date)
	if build_no_sign:
		sign_config = 'CODE_SIGNING_REQUIRED=NO'
	result_bundle_path = "${HOME}/Library/Developer/Xcode/DerivedData/%s" % (log_dir)
	cmds.append('rm -rf \"%s\"' % result_bundle_path)
	cmds.append('rm -rf \"%s\"' % archive_path)
	if build_log_out == 0:
		#cmd = 'xcodebuild -quiet archive -workspace \"%s\" -scheme \"%s\" -configuration \"%s\" %s -sdk iphoneos -archivePath \"%s\" -SYMROOT=\"%s/Build/Intermediates.noindex/%s/BuildProductsPath\"' % (workspace, target_name, configure, archs_str, archive_path, confuse_utils.pstr(workspace_dir), target_name)
		cmd = 'xcodebuild -quiet archive  -resultBundlePath \"%s\" -workspace \"%s\" -scheme \"%s\" -configuration \"%s\" %s -sdk iphoneos -archivePath \"%s\"  %s' % (result_bundle_path, workspace, target_name, configure, archs_str, archive_path, sign_config)
	else:
		#cmd = 'xcodebuild archive -workspace \"%s\" -scheme \"%s\" -configuration \"%s\" %s -sdk iphoneos -archivePath \"%s\"  -SYMROOT=\"%s/Build/Intermediates.noindex/%s/BuildProductsPath\" > \"%s/xcode-build-log.txt\"' % (workspace, target_name, configure, archs_str, archive_path, confuse_utils.pstr(workspace_dir), target_name, package_dir)
		cmd = 'xcodebuild archive -resultBundlePath \"%s\"  -workspace \"%s\" -scheme \"%s\" -configuration \"%s\" %s -sdk iphoneos -archivePath \"%s\" %s > \"%s/xcode-build-log.txt\"' % (result_bundle_path, workspace, target_name, configure, archs_str, archive_path, package_dir, sign_config)
	cmds.append(cmd)

	cmds.append('rm -rf \"%s.back\"' % (archive_path))

	cmd = 'cp -r \"%s\" \"%s.back\"' % (archive_path, archive_path)
	cmds.append(cmd)
	
	for cmd in cmds:
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)

	if os.path.exists(archive_path) == False:
		print('not found %s.' % archive_path)
		sys.exit(1)

	pass

#cd /Users/crab/Documents/myprojects/iOS-artifact/resource/projectmanager/other/script
#python archive_workspace.py /Users/crab/Documents/swapshell/samplecode/objc_sample_code/SampleCode.xcworkspace /Users/crab/Library/ipa-artifact com.zuimeiqidai.my.samplecode SampleCode Release
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 7:
		print('python archive_workspace.py [workspace] [work dir] [bundle id] [target name] [archs] [Debug/Release]')
		return
	archive_workspace(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6])
	
main(sys.argv)