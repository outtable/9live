#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def remove_temp_files(work_dir, bundle_id):
	print('##remove temp files##')
	confuse_utils.clean_temp_files(work_dir, bundle_id)
	pass

def main(argv):
	if len(argv) != 3:
		print('python remove_temp_files.py [work dir] [bundle id]')
		sys.exit(1)
	
	remove_temp_files(argv[1], argv[2])

main(sys.argv)