#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def preprocess_pod_resource_sh(work_dir, bundle_id, target_name, sh_file):
	print('#preprocess target %s pod resource install sh %s ' % (target_name, sh_file))
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	file_name = '%s/%s_environment_variables.txt' % (package_dir, target_name)
	envs = confuse_utils.read_properties_file(file_name)
	lines = []

	with open(sh_file, 'r') as f:
		lines = f.readlines()
		f.close()
	os.rename(sh_file, sh_file + ".back")

	confuse_utils.add_backup_file(work_dir, bundle_id, sh_file, sh_file + ".back")

	with open(sh_file, 'w') as f:
		for line in lines:
			start = line.find('install_resource')
			if start != -1:
				start = line.find('\"')
				end = line.rfind('\"')
				if start != -1 and end != -1:
					filename = line[start + 1 : end]
					src_file = confuse_utils.replace_text_vars(envs, filename)
					dst_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
					f.write('%s\"%s\"%s' % (line[0:start], dst_file, line[end + 1:]))
				else:
					f.write(line)
			else:
				f.write(line)
		f.close()

	#os.remove(sh_file + '.back')
	pass

def main(argv):
	if len(argv) != 5:
		print('python preprocess_pod_resource_sh.py [work dir] [bundle id] [target name] [sh file]')
		sys.exit(1)
		return
		
	preprocess_pod_resource_sh(argv[1], argv[2], argv[3], argv[4])

main(sys.argv)