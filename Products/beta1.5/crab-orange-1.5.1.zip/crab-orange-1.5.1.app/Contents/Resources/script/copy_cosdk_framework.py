#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
import os
import confuse_utils
import json
import shutil
import importlib

importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

def copy_cosdk_framework(work_dir, bundle_id, main_project_file, main_bundle_id, main_target_name, configure, workspace_info_file):
	print('#copy cosdk framework')
	configure = 'Release'

	debug_mode = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'debug-mode', False)
	if debug_mode:
		configure = 'Debug'
	
	use_dyn_cosdk = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'use-dyn-cosdk', False)
	if use_dyn_cosdk == False:
		return
	
	cosdk_name = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cosdk-name', 'COSDK')

	workspace_dir = os.environ.get('WORKSPACE_DIR')
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, main_target_name, 'target')
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, main_target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	archive_path = '%s/%s.xcarchive' % (package_dir, main_target_name)
	app_path = '%s/Products/Applications/%s' % (archive_path, app_product_file)
	app_cosdk_framework_path = '%s/Frameworks/%s.framework' % (app_path, cosdk_name)

	depend_files = confuse_utils.read_settings_file(package_dir + '/depend_files.txt')
	cosdk_items = []

	if 'cosdk' in depend_files:
		cosdk_items = depend_files['cosdk']

	cosdk_framework_file = ''

	for item in cosdk_items:
		if item.endswith('%s.framework/%s' % (cosdk_name, cosdk_name)):
			item = item[0:-(len(cosdk_name) + 1)]
			cosdk_framework_file = '%s/%s' % (workspace_dir, item.replace('{..}/', '../'))
	
	if os.path.exists(app_cosdk_framework_path):
		shutil.rmtree(app_cosdk_framework_path)

	shutil.copytree(cosdk_framework_file, app_cosdk_framework_path)
	print('bundleid:%s' % bundle_id)
	print('target:%s' % main_target_name)
	mp,has_config,identify = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, bundle_id, main_target_name)

	sign_key = mp['CODE_SIGN_IDENTITY']
	cmd = '/usr/bin/codesign -f -s \"%s\" --preserve-metadata=identifier,entitlements,flags \"%s\"' % (sign_key, app_cosdk_framework_path)
	print(cmd)
	ret = os.system(cmd)
	if ret != 0:
		print('ErrorCode(%d)' % ret) 
		sys.exit(1)
	#sys.exit(1)

#python '/Users/crab/Documents/myproject/ios-confuse/resource/crab-orange/resource/script/swift_bridge_header_make.py' '/Users/crab/Library/ipa-artifact' 'com.zuimeiqidai.ios.test.objc' 'test.objc' 'TestObjC' '/Users/carb/Library/ipa-artifact/packages/com.zuimeiqidai.ios.test.objc/workspace.profile'  
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 8:
		print('python copy_cosdk_framework.py [work dir] [bundle id] [main project file] [main bundle id] [main target name] [configure] [workspace info file]')
		sys.exit(1)
	copy_cosdk_framework(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7])

print(sys.argv)
main(sys.argv)
